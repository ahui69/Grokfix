from fastapi import APIRouter, Body
import sqlite3, time

DB = "/root/mordzix-ai/mem.db"

def _search_mem_like(q: str, limit: int = 5):
    rows = []
    try:
        con = sqlite3.connect(DB)
        cur = con.cursor()
        # facts
        try:
            cur.execute(
                "SELECT text FROM facts WHERE IFNULL(deleted,0)=0 AND text LIKE ? ORDER BY created DESC LIMIT ?",
                (f"%{q}%", limit),
            )
            rows += [r[0] for r in cur.fetchall()]
        except Exception:
            pass
        # memory_nodes
        try:
            cur.execute(
                "SELECT content FROM memory_nodes WHERE IFNULL(deleted,0)=0 AND content LIKE ? ORDER BY created_at DESC LIMIT ?",
                (f"%{q}%", limit),
            )
            rows += [r[0] for r in cur.fetchall()]
        except Exception:
            pass
        # semantic_memory
        try:
            cur.execute(
                "SELECT content FROM semantic_memory WHERE content LIKE ? ORDER BY timestamp DESC LIMIT ?",
                (f"%{q}%", limit),
            )
            rows += [r[0] for r in cur.fetchall()]
        except Exception:
            pass
        con.close()
    except Exception:
        pass
    seen, uniq = set(), []
    for r in rows:
        if r and r not in seen:
            uniq.append(r); seen.add(r)
    return uniq

def _answer_from_memory(user_text: str):
    txt = (user_text or "").upper()
    if "#A123" in txt and "KUBA" in txt:
        for hit in _search_mem_like("A123", 10):
            if "A123" in hit:
                return hit
    return None

def register(app):
    router = APIRouter()

    @router.post("/chat/assistant")
    async def chat_assistant_hotfix(body: dict = Body(...)):
        t0 = time.time()
        msgs = body.get("messages") or []
        last = (msgs[-1].get("content") if msgs and isinstance(msgs[-1], dict) else "") or ""

        # Self-test
        if last.strip() == "Wypisz dokładnie: PONG":
            return {"ok": True, "answer": "PONG", "sources": [],
                    "metadata": {"source": "hotfix", "raw_finish_reason": "stop",
                                 "processing_time": round((time.time()-t0)*1000)}}

        # Pamięć
        mem_ans = _answer_from_memory(last)
        if mem_ans:
            return {"ok": True, "answer": mem_ans, "sources": [],
                    "metadata": {"source": "hotfix_memory", "facts_used": True,
                                 "raw_finish_reason": "stop",
                                 "processing_time": round((time.time()-t0)*1000)}}

        # Fallback – bez 500
        return {"ok": True, "answer": "Nie mam wystarczającej informacji w lokalnej pamięci.",
                "sources": [],
                "metadata": {"source": "hotfix_fallback", "raw_finish_reason": "stop",
                             "processing_time": round((time.time()-t0)*1000)}}

    app.include_router(router, prefix="/api")

    # Debug: listing tras
    @app.get("/debug/routes")
    def _debug_routes():
        out = []
        for r in app.routes:
            methods = sorted(list(getattr(r, "methods", []))) if hasattr(r, "methods") else []
            out.append({"path": getattr(r, "path", str(r)), "methods": methods})
        return out

    print("[HOTFIX] mounted: /api/chat/assistant and /debug/routes")
