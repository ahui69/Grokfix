#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
assistant_endpoint.py — czat z:
- AUTH + rate limit
- Pamięć (facts SQLite) + załączniki
- Web research (triggery) + guard
- Self-critique po odpowiedzi (LLM ocenia: truthful/complete/aktualne/logiczne)
- Auto-research (autonauka) jeśli odpowiedź słaba → opcjonalna rafinacja
- Inteligentna metapamięć → zapis do memory_meta.jsonl
- Stream SSE (po streamie robi self-critique i meta-log w tle)
"""

from typing import List, Dict, Any, Optional, Tuple, AsyncIterator
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
# --- META MEMORY IMPORT (safe) ---
try:
    from core.meta_memory import log_meta_event
except Exception:
    def log_meta_event(**k):
        pass

from datetime import datetime
import os, json, hashlib, re, time, sqlite3, inspect, asyncio

# ────────────────────────────────────────────────────────────────────────────────
# Logi

try:
    from core.helpers import log_warning, log_info
except Exception as e:
    def log_info(msg: str): print(msg)
    def log_warning(msg: str): print(msg)
    print(f"[helpers:fallback] {e}")

# Security
try:
    from core.security import security_manager, get_client_ip
except Exception as e:
    log_warning(f"[SEC] core.security not available, using fallback: {e}")
    class _SecFB:
        def check_rate_limit(self, *a, **k): return True
        def record_failed_attempt(self, *a, **k): log_warning("[SEC] record_failed_attempt (fallback)")
    security_manager = _SecFB()
    def get_client_ip(req: Request):
        return (getattr(getattr(req, "client", None), "host", None)
                or req.headers.get("x-forwarded-for","0.0.0.0").split(",")[0].strip())

# LLM
try:
    from .llm import call_llm_stream_with_fallback, chat_completion
except Exception as e:
    call_llm_stream_with_fallback = None
    chat_completion = None
    log_warning(f"[LLM] Streaming or chat unavailable (fallback): {e}")

# Intent (opcjonalnie)
try:
    from .intent_detector import detect_intent, get_mode_prompt_addon
except Exception as e:
    log_warning(f"[INTENT] intent_detector not available: {e}")
    def detect_intent(_text: str):
        class _I:
            mode = os.getenv("DEFAULT_INTENT_MODE", "casual")
        return _I()
    def get_mode_prompt_addon(_mode: str) -> str:
        return ""

# Persona
try:
    from .config import MORDZIX_SYSTEM_PROMPT
except Exception:
    MORDZIX_SYSTEM_PROMPT = ""

# Metapamięć / Auto-research / Krytyka
from .meta_memory import (
    log_meta_interaction,
    critique_answer,
    should_trigger_auto_research,
    auto_research_and_learn,
    refine_answer_with_facts,
)

# ────────────────────────────────────────────────────────────────────────────────
# ENV helpers

def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        v = int(raw.strip()); return v if v > 0 else default
    except Exception:
        log_warning(f"[ENV] Invalid int for {name}='{raw}', using {default}")
        return default

def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None: return default
    val = raw.strip().lower()
    if val in ("1","true","yes","y","on"): return True
    if val in ("0","false","no","n","off"): return False
    log_warning(f"[ENV] Invalid bool for {name}='{raw}', using {default}")
    return default

STREAM_TIMEOUT_S             = _env_int("CHAT_STREAM_TIMEOUT_S", 120)
WEB_MAX_RESULTS              = _env_int("CHAT_WEB_MAX_RESULTS", 8)
ALLOW_FORCE_WEB              = _env_bool("CHAT_ALLOW_FORCE_WEB", False)

REQUIRE_AUTH                 = _env_bool("REQUIRE_AUTH", True)
ALLOW_PLACEHOLDER_AUTH       = _env_bool("ALLOW_PLACEHOLDER_AUTH", False)
CHAT_ALLOW_ANON              = _env_bool("CHAT_ALLOW_ANON", False)

ATTACH_TEXT_LIMIT_CHARS      = _env_int("ATTACH_TEXT_LIMIT_CHARS", 15000)
ATTACH_PDF_MAX_PAGES         = _env_int("ATTACH_PDF_MAX_PAGES", 10)
ATTACH_PDF_CHARS_PER_PAGE    = _env_int("ATTACH_PDF_CHARS_PER_PAGE", 3000)
ATTACH_DOCX_LIMIT_CHARS      = _env_int("ATTACH_DOCX_LIMIT_CHARS", 10000)

MEM_DB                       = os.getenv("MEM_DB", "/root/mordzix-ai/mem.db")
MEM_TOPK                     = _env_int("MEM_TOPK", 5)
MEM_TIMEOUT_S                = float(os.getenv("MEM_QUERY_TIMEOUT", "0.150"))

AUTO_RESEARCH_ON_NONSTREAM   = _env_bool("AUTO_RESEARCH_ON_NONSTREAM", True)
AUTO_RESEARCH_ON_STREAM      = _env_bool("AUTO_RESEARCH_ON_STREAM", False)  # w stream robimy to asynchronicznie po

# ────────────────────────────────────────────────────────────────────────────────
# Modele

class Message(BaseModel):
    role: str
    content: str
    attachments: Optional[List[Dict[str, Any]]] = []

class ChatRequest(BaseModel):
    messages: List[Message]
    user_id: Optional[str] = "default"
    session_id: Optional[str] = None
    model: Optional[str] = None
    use_memory: bool = True
    use_research: bool = True
    internet_allowed: Optional[bool] = True
    web_search: Optional[bool] = None
    auto_learn: Optional[bool] = True
    use_batch_processing: Optional[bool] = True
    attachments: Optional[List[Dict[str, Any]]] = []
    force_web: Optional[bool] = None
    debug: Optional[bool] = False

    def __str__(self) -> str:
        mcnt = len(self.messages or [])
        attc = len(self.attachments or [])
        return (f"ChatRequest(msgs={mcnt}, session={self.session_id}, model={self.model}, "
                f"internet_allowed={self.internet_allowed}, force_web={self.force_web}, "
                f"web_search={self.web_search}, attachments={attc})")
    __repr__ = __str__

class ChatResponse(BaseModel):
    ok: bool
    answer: str
    sources: Optional[List[Dict[str, Any]]] = []
    metadata: Dict[str, Any] = {}

# ────────────────────────────────────────────────────────────────────────────────
router = APIRouter(prefix="/api/chat")

# Auth
AUTH_TOKEN = os.getenv("AUTH_TOKEN", "__CHANGE_ME_AUTH_TOKEN__")
if REQUIRE_AUTH and AUTH_TOKEN == "__CHANGE_ME_AUTH_TOKEN__" and not ALLOW_PLACEHOLDER_AUTH:
    log_warning("[AUTH] AUTH_TOKEN is default placeholder. Set AUTH_TOKEN or ALLOW_PLACEHOLDER_AUTH=1 (DEV ONLY).")
    raise RuntimeError("AUTH_TOKEN not configured")

# Limity
RATE_LIMIT_CHAT = 60
RATE_LIMIT_CHAT_STREAM = 60
MAX_MESSAGE_LENGTH = 50000
MAX_MESSAGES_COUNT = 100

# ────────────────────────────────────────────────────────────────────────────────
# Auth + rate limit

def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()[:16]

def _derive_anon_user_id(req: Request) -> str:
    ip = get_client_ip(req)
    ua = req.headers.get("User-Agent", "-")
    mat = f"{ip}|{ua}".encode()
    return "anon-" + hashlib.sha256(mat).hexdigest()[:16]

def _get_user_id(req: Request, token: Optional[str]) -> str:
    if token: return _hash_token(token)
    return _derive_anon_user_id(req) if CHAT_ALLOW_ANON else "default"

def _auth_with_rate_limit(req: Request, limit: int) -> str:
    client_ip = get_client_ip(req)
    path = req.url.path
    if not security_manager.check_rate_limit(client_ip, path, limit):
        log_warning(f"[CHAT] Rate limit exceeded for {client_ip} on {path}")
        raise HTTPException(429, "Rate limit exceeded. Try later.")

    auth = req.headers.get("Authorization", "")
    token = auth.replace("Bearer ", "").strip() if auth.startswith("Bearer ") else ""

    if REQUIRE_AUTH and token != AUTH_TOKEN:
        if CHAT_ALLOW_ANON and token == "":
            uid = _get_user_id(req, token)
            log_warning(f"[AUTH] Anonymous access allowed → {uid}")
            return uid
        security_manager.record_failed_attempt(client_ip)
        raise HTTPException(401, "Unauthorized")

    return _get_user_id(req, token)

def _validate_session_ownership(session_id: Optional[str], user_id: str):
    if not session_id: return
    try:
        from .sessions import verify_session_ownership
        if not verify_session_ownership(session_id, user_id):
            raise HTTPException(403, "Access denied: you don't own this session")
    except ImportError as e:
        log_warning(f"[SESSIONS] verify_session_ownership not available: {e}")

# ────────────────────────────────────────────────────────────────────────────────
# Web triggers (PL/EN)

_POS = [
    r"\bsprawd[źz]\b", r"\bsprawdzisz\b", r"\bwyszukaj\b", r"\bposzukaj\b",
    r"\bprzeszukaj\b", r"\bprzejrzyj\b", r"\bwygoogluj\b", r"\bgoogle\b",
    r"\bznajd[źz]\b", r"\bw (internecie|sieci|necie)\b", r"\bonline\b",
    r"\bnajnowsz(e|y|a)\b", r"\baktualn(e|y|a)\b", r"\bdzi(si|ś)aj\b",
    r"\bteraz\b", r"\bwczoraj\b",
    r"\bwynik (meczu|spotkania)\b", r"\bterminarz\b", r"\btabela\b", r"\bskład(y)?\b",
    r"\bkurs( (usd|eur|pln|btc|eth))?\b", r"\bnotowani(a|e)\b", r"\bcena(y)?\b",
    r"\bpor[óo]wnaj cen(y|e)\b", r"\brecenzj(e|a)\b", r"\bofert(y|a)\b", r"\bpogoda\b",
    r"\bzweryfikuj\b", r"\bpotwierd[źz]\b",
    r"\bpoka[żz] (źr[óo]dła|linki?)\b", r"\bpodaj linki?\b",
    r"\bzr[óo]b research\b", r"\bresearch\b",
    r"\bsearch\b", r"\blook up\b", r"\bfind\b", r"\bgoogle it\b",
    r"\bcheck (online|on the web)\b", r"\bverify\b", r"\bdouble[- ]check\b",
    r"\bshow sources?\b", r"\bgive me links?\b",
    r"\blatest\b", r"\bcurrent\b", r"\bnews\b",
    r"\bresult\b", r"\bscore\b", r"\bfixture(s)?\b", r"\bstanding(s)?\b",
    r"\bprice(s)?\b", r"\brate(s)?\b", r"\bweather\b",
]
_NEG = [
    r"\bbez internetu\b", r"\boffline\b", r"\boffline only\b",
    r"\bnie (sprawdzaj|wyszukuj|szukaj)\b", r"\bniczego nie sprawdzaj\b",
    r"\bno internet\b", r"\bdon'?t (search|use (the )?web)\b", r"\bno web\b",
]
_POS_RE = [re.compile(p, re.IGNORECASE) for p in _POS]
_NEG_RE = [re.compile(p, re.IGNORECASE) for p in _NEG]

def _sanitize_text(t: str) -> str:
    t = (t or "").replace("\u200b"," ").replace("\u2060"," ")
    t = re.sub(r"\s+", " ", t).strip()
    return t

def _find_trigger_phrase(text: str):
    for rx in _NEG_RE:
        m = rx.search(text)
        if m: return (m.group(0), "negative_trigger")
    for rx in _POS_RE:
        m = rx.search(text)
        if m: return (m.group(0), "explicit_trigger")
    return (None, None)

def _should_use_web_from_text(text: str, internet_allowed: Optional[bool], force_web: Optional[bool]):
    if internet_allowed is False:
        return (False, "disabled_by_flag", None)
    t = _sanitize_text(text)
    if not t: return (False, "no_text", None)
    matched, reason = _find_trigger_phrase(t)
    if reason == "negative_trigger": return (False, reason, matched)
    if reason == "explicit_trigger": return (True, reason, matched)
    if ALLOW_FORCE_WEB and bool(force_web) is True: return (True, "force_web_flag", None)
    if re.search(r"\b20\d{2}\b", t) or re.search(r"\b(dzi[śs]|teraz)\b", t, re.I):
        return (True, "heuristics:year/timeword", None)
    return (False, "no_trigger", None)

# ────────────────────────────────────────────────────────────────────────────────
# Pamięć (SQLite) → fakty

_SQL_MEMORY = """
WITH rows(content) AS (
    SELECT text    FROM facts         WHERE IFNULL(deleted,0)=0
    UNION ALL
    SELECT content FROM memory_nodes  WHERE IFNULL(deleted,0)=0
)
SELECT content
  FROM rows
 WHERE content LIKE ? OR content LIKE ?
 ORDER BY 1 DESC
 LIMIT ?;
"""

def _like_term(s: str) -> str:
    s = (s or "").strip()
    if not s: return "%"
    return f"%{s[:200]}%"

def _extract_query(msgs: List[Message]) -> str:
    for m in reversed(msgs or []):
        if (m.role or "").lower() == "user":
            return (m.content or "").strip()
    return " ".join((m.content or "") for m in msgs or []).strip()

def _memory_facts(query: str, topk: int) -> List[str]:
    if not query or not os.path.exists(MEM_DB):
        return []
    try:
        con = sqlite3.connect(MEM_DB, timeout=MEM_TIMEOUT_S)
        con.row_factory = lambda cur,row: row[0]
        cur = con.cursor()
        rows = cur.execute(_SQL_MEMORY, (_like_term(query), "%", int(topk))).fetchall()
        con.close()
        return [r for r in rows if r]
    except Exception as e:
        log_warning(f"[MEM/DB] query failed: {e}")
        return []

# ────────────────────────────────────────────────────────────────────────────────
# Załączniki

def _attachments_context(attachments: List[Dict[str,Any]]) -> Tuple[str, Dict[str,int]]:
    if not attachments:
        return "", {"total":0,"text":0,"pdf":0,"docx":0,"image":0,"other":0,"errors":0}
    stats = {"total":0,"text":0,"pdf":0,"docx":0,"image":0,"other":0,"errors":0}
    ctx = ""
    try:
        from pathlib import Path
        workspace = Path(os.getenv("WORKSPACE", "."))
        uploads = workspace / "uploads"
        for att in attachments:
            stats["total"] += 1
            name = att.get("name", att.get("filename", "plik"))
            file_id = att.get("id","")
            file_url = att.get("url","")
            path = uploads / file_id if file_id else (uploads / file_url.replace("/api/files/","") if file_url and file_url.startswith("/api/files/") else None)

            def _append(txt: str):
                nonlocal ctx
                ctx += txt

            if path and path.exists():
                ext = path.suffix.lower()
                try:
                    if ext in {'.txt','.md','.json','.csv','.xml','.html','.py','.js','.ts','.css','.log','.yaml','.yml','.ini','.cfg','.conf'}:
                        content = path.read_text(encoding='utf-8', errors='ignore')[:ATTACH_TEXT_LIMIT_CHARS]
                        _append(f"\n\n📎 ZAŁĄCZNIK [{name}]:\n```\n{content}\n```")
                        stats["text"] += 1
                    elif ext == '.pdf':
                        try:
                            import fitz  # PyMuPDF
                            doc = fitz.open(str(path))
                            t = ""
                            for page in doc[:ATTACH_PDF_MAX_PAGES]:
                                t += page.get_text()[:ATTACH_PDF_CHARS_PER_PAGE]
                            doc.close()
                            if t.strip():
                                _append(f"\n\n📎 ZAŁĄCZNIK PDF [{name}]:\n```\n{t[:ATTACH_TEXT_LIMIT_CHARS]}\n```")
                            else:
                                _append(f"\n\n📎 ZAŁĄCZNIK [{name}]: [PDF] bez tekstu")
                            stats["pdf"] += 1
                        except Exception:
                            _append(f"\n\n📎 ZAŁĄCZNIK [{name}]: [PDF]")
                            stats["pdf"] += 1
                    elif ext == '.docx':
                        try:
                            import docx  # python-docx
                            d = docx.Document(str(path))
                            t = "\n".join(p.text for p in d.paragraphs)[:ATTACH_DOCX_LIMIT_CHARS]
                            _append(f"\n\n📎 ZAŁĄCZNIK DOCX [{name}]:\n```\n{t}\n```")
                        except Exception:
                            _append(f"\n\n📎 ZAŁĄCZNIK [{name}]: [DOCX]")
                        stats["docx"] += 1
                    elif ext in {'.png','.jpg','.jpeg','.gif','.webp','.bmp'}:
                        _append(f"\n\n📎 ZAŁĄCZNIK [{name}]: [OBRAZ]")
                        stats["image"] += 1
                    else:
                        _append(f"\n\n📎 ZAŁĄCZNIK [{name}]: [PLIK {ext.upper()}]")
                        stats["other"] += 1
                except Exception:
                    _append(f"\n\n📎 ZAŁĄCZNIK [{name}]: (błąd odczytu)")
                    stats["errors"] += 1
            else:
                mime = (att.get("mime") or "").lower()
                if "image" in mime or att.get("kind") == "image":
                    ctx += f"\n\n📎 ZAŁĄCZNIK [{name}]: [OBRAZ]"
                    stats["image"] += 1
                elif "pdf" in mime:
                    ctx += f"\n\n📎 ZAŁĄCZNIK [{name}]: [PDF]"
                    stats["pdf"] += 1
                elif "docx" in mime:
                    ctx += f"\n\n📎 ZAŁĄCZNIK [{name}]: [DOCX]"
                    stats["docx"] += 1
                else:
                    ctx += f"\n\n📎 ZAŁĄCZNIK [{name}]: [PLIK]"
                    stats["other"] += 1
    except Exception as e:
        log_warning(f"[ATTACH] Error: {e}")
        stats["errors"] += 1
    return ctx, stats

# ────────────────────────────────────────────────────────────────────────────────
# Pomocnicze

def _last_user_text(msgs: List[Message]) -> str:
    for m in reversed(msgs):
        if (m.role or "").lower() == "user":
            return m.content or ""
    return ""

def _compose_system_prompt(base_persona: str, mode_addon: str,
                           mem_facts: List[str], attach_ctx: str, web_block: str) -> str:
    facts_block = "\n".join(f"- {f}" for f in mem_facts) if mem_facts else "(brak dopasowanych faktów)"
    memory_section = f"=== PAMIĘĆ (LTM/STM) ===\n{facts_block}\n=== KONIEC PAMIĘCI ==="
    guard_web = ""
    if web_block:
        guard_web = (
            "\n\n[GUARD]\n"
            "Używaj WYŁĄCZNIE informacji z sekcji PAMIĘĆ i AKTUALNE DANE Z INTERNETU. "
            "Jeśli czegoś brakuje — powiedz to wprost. Nie wymyślaj dat, wyników, cen ani linków.\n"
        )
    sections = [
        base_persona or "",
        mode_addon or "",
        guard_web,
        memory_section,
        attach_ctx or "",
        web_block or ""
    ]
    return "\n\n".join([s for s in sections if s.strip()])

def _build_web_block(query: str, results: List[Dict[str,Any]]) -> Tuple[str, List[Dict[str,Any]]]:
    if not results:
        return "", []
    today = datetime.now().strftime("%d.%m.%Y")
    lines = []
    for r in results:
        title = r.get("title","").strip()
        snip  = (r.get("snippet","") or "").strip()
        url   = (r.get("url","") or "").strip()
        if title or snip or url:
            lines.append(f"• {title}: {snip[:400]} (źródło: {url})")
    block = "\n\n🔍 AKTUALNE DANE Z INTERNETU (DZISIAJ: "+today+"):\n" + "\n".join(lines)
    srcs = [{"title": r.get("title",""), "url": r.get("url","")} for r in results]
    return block, srcs

# Web search (policy wrapper)
async def _smart_web(q: str, k: int) -> List[Dict[str, str]]:
    try:
        from .research_policy import smart_web_search
        res = await smart_web_search(q, max_results=k)
        return res or []
    except Exception as e:
        log_warning(f"[WEB] smart_web_search failed: {e}")
        return []

# Pamięć/sesje (opcjonalnie)
def _get_memory_savers():
    try:
        from .memory import memory_add_conversation
    except Exception as e:
        log_warning(f"[MEMORY] memory_add_conversation not available: {e}")
        def memory_add_conversation(*a, **k): log_warning("[MEMORY] fallback memory_add_conversation")
    try:
        from .sessions import add_conversation_pair
    except Exception as e:
        log_warning(f"[SESSIONS] add_conversation_pair not available: {e}")
        def add_conversation_pair(*a, **k): log_warning("[SESSIONS] fallback add_conversation_pair")
    return memory_add_conversation, add_conversation_pair

# ────────────────────────────────────────────────────────────────────────────────
# /assistant — non-stream

@router.post("/assistant", response_model=ChatResponse)
async def chat_assistant(body: ChatRequest, req: Request):
    log_info(f"[CHAT] POST /assistant {body}")
    t_all = time.time()
    try:
        from .config import MEMORY_ENABLED
    except Exception:
        MEMORY_ENABLED = True

    mem_add, sess_add = _get_memory_savers()
    user_id = _auth_with_rate_limit(req, RATE_LIMIT_CHAT)

    if len(body.messages) > MAX_MESSAGES_COUNT:
        raise HTTPException(400, f"Too many messages (max {MAX_MESSAGES_COUNT})")
    for m in body.messages:
        if len(m.content or "") > MAX_MESSAGE_LENGTH:
            raise HTTPException(413, f"Message too long (max {MAX_MESSAGE_LENGTH} chars)")

    session_id = body.session_id
    _validate_session_ownership(session_id, user_id)

    last_user = _sanitize_text(_last_user_text(body.messages))

    # INTENT
    intent = detect_intent(last_user)
    mode = getattr(intent, "mode", "casual")
    mode_addon = get_mode_prompt_addon(mode)

    # Pamięć + załączniki
    mem_facts = _memory_facts(_extract_query(body.messages), MEM_TOPK) if body.use_memory else []
    attach_ctx, attach_stats = _attachments_context(body.attachments or [])

    # Web?
    web_used, reason, matched = _should_use_web_from_text(last_user, internet_allowed=body.internet_allowed, force_web=body.force_web)
    sources = []
    web_block = ""
    if body.use_research and web_used:
        t_web = time.time()
        web_results = await _smart_web(f"{last_user} {datetime.now().strftime('%Y')}", WEB_MAX_RESULTS)
        web_block, sources = _build_web_block(last_user, web_results)
        web_ms = int(1000*(time.time()-t_web))
    else:
        web_ms = 0

    # System prompt i odpowiedź (1. przebieg)
    system_content = _compose_system_prompt(MORDZIX_SYSTEM_PROMPT, mode_addon, mem_facts, attach_ctx, web_block)
    messages = [{"role":"system","content":system_content}]
    messages.extend({"role":m.role, "content":m.content} for m in body.messages)

    if chat_completion is None:
        raise HTTPException(500, "LLM not available")

    t_gen = time.time()
    answer1 = await chat_completion(messages, temperature=0.7, model=body.model)
    gen_ms = int(1000*(time.time()-t_gen))
    answer_final = answer1 or ""

    # Self-critique
    t_crit = time.time()
    crit = await critique_answer(last_user, answer_final, sources)
    crit_ms = int(1000*(time.time()-t_crit))

    # Auto-research + rafinacja (non-stream)
    used_auto = False
    refined = False
    ar_ms = 0
    if body.auto_learn and AUTO_RESEARCH_ON_NONSTREAM and should_trigger_auto_research(crit):
        t_ar = time.time()
        auto = await auto_research_and_learn(last_user, user_id=user_id)
        ar_ms = int(1000*(time.time()-t_ar))
        facts = auto.get("facts", []) or []
        new_sources = auto.get("sources", []) or []
        if facts:
            used_auto = True
            # rafinacja odpowiedzi
            answer2 = await refine_answer_with_facts(last_user, answer_final, facts)
            if answer2.strip():
                refined = True
                answer_final = answer2.strip()
            sources = (sources or []) + [{"title": s.get("title",""), "url": s.get("url","")} for s in new_sources][:WEB_MAX_RESULTS]

    # zapisy pamięci
    try:
        if MEMORY_ENABLED and last_user and answer_final:
            mem_add(user_id=user_id, user_msg=last_user, assistant_msg=answer_final, intent="chat")
    except Exception as e:
        log_warning(f"[MEMORY] save failed: {e}")
    try:
        if session_id and last_user and answer_final:
            sess_add(session_id, last_user, answer_final, user_attachments=body.attachments or [], user_id=user_id)
    except Exception as e:
        log_warning(f"[SESSION] save failed: {e}")

    # META MEMORY LOG
    durations = {
        "web_ms": web_ms,
        "gen_ms": gen_ms,
        "crit_ms": crit_ms,
        "auto_research_ms": ar_ms,
        "total_ms": int(1000*(time.time()-t_all)),
    }
    try:
        log_meta_interaction(
            user_id=user_id,
            session_id=session_id,
            request_id=req.headers.get("X-Request-ID"),
            intent_mode=mode,
            used_web=bool(web_used),
            used_auto_research=bool(used_auto),
            improved_with_facts=bool(refined),
            critique=crit,
            durations_ms=durations,
            error=None,
            timeout=False,
            tokens=None,
            notes={"web_reason": reason, "web_phrase": matched, "facts_count": len(mem_facts)}
        )
    except Exception as e:
        log_warning(f"[META] log failed: {e}")

    meta = {
        "session_id": session_id,
"intent_mode": mode,
"web_used": web_used,
"web_reason": reason,
"web_matched_phrase": matched,
"attachments": attach_stats,
"facts_count": len(mem_facts),
"critique": crit,
"auto_research": {"used": used_auto, "refined": refined},
"durations_ms": durations,
}
        # --- META: non-stream log ---
try:
            log_meta_event(
                user_id=user_id, session_id=session_id,
question=last_user, answer=result.get("answer",""),
intent="chat", web_used=None, web_reason=None,
complete=bool(result.get("answer")), error=False, timeout=False,
durations_ms=meta.get("durations_ms"), model=body.model or None,
streaming=False, extra=meta
)
# except Exception as _e:  # osierocony except – wyłączony
        print(f"[META] non-stream log failed: {_e}")
return ChatResponse(ok=True, answer=answer_final, sources=sources[:WEB_MAX_RESULTS], metadata=meta)

# ────────────────────────────────────────────────────────────────────────────────
# /assistant/stream — SSE (self-critique + meta log po streamie w tle)

@router.post("/assistant/stream")
async def chat_assistant_stream(body: ChatRequest, req: Request):
    log_info(f"[CHAT] POST /assistant/stream {body}")
    if call_llm_stream_with_fallback is None:
        raise HTTPException(500, "LLM streaming not available")

    try:
        from .config import MEMORY_ENABLED
    except Exception as e:
        pass
#     except Exception:  # osierocony except – wyłączony
    MEMORY_ENABLED = True

    mem_add, sess_add = _get_memory_savers()
    user_id = _auth_with_rate_limit(req, RATE_LIMIT_CHAT_STREAM)

    if len(body.messages) > MAX_MESSAGES_COUNT:
        raise HTTPException(400, f"Too many messages (max {MAX_MESSAGES_COUNT})")
    for m in body.messages:
        if len(m.content or "") > MAX_MESSAGE_LENGTH:
            raise HTTPException(413, f"Message too long (max {MAX_MESSAGE_LENGTH} chars)")

    session_id = body.session_id
    _validate_session_ownership(session_id, user_id)

    attachments = body.attachments or []
    last_user = _sanitize_text(_last_user_text(body.messages))

    # INTENT
    intent = detect_intent(last_user)
    mode = getattr(intent, "mode","casual")
    mode_addon = get_mode_prompt_addon(mode)

    # Pamięć + załączniki
    mem_facts = _memory_facts(_extract_query(body.messages), MEM_TOPK) if body.use_memory else []
    attach_ctx, attach_stats = _attachments_context(attachments)

    # Web (przed streamem; bez autonauki — robi się asynchronicznie po)
    web_used, reason, matched = _should_use_web_from_text(
        last_user, internet_allowed=body.internet_allowed, force_web=body.force_web
    )
    sources = []
    web_block = ""
    if body.use_research and web_used:
        try:
            web_results = await _smart_web(f"{last_user} {datetime.now().strftime('%Y')}", WEB_MAX_RESULTS)
        except Exception as e:
            pass
    web_block, sources = _build_web_block(last_user, web_results)
#     except Exception as e:  # osierocony except – wyłączony
        log_warning(f"[STREAM] web error: {e}")

    # System prompt
    system_content = _compose_system_prompt(MORDZIX_SYSTEM_PROMPT, mode_addon, mem_facts, attach_ctx, web_block)
    messages = [{"role":"system","content":system_content}]
    messages.extend({"role":m.role, "content":m.content} for m in body.messages)
    stream_model = body.model or None

    t_all = time.time()
async def generate() -> AsyncIterator[str]:
        full = ""
error = False
t_gen = time.time()

try:
            yield "data: " + json.dumps({"type":"start"}) + "\n\n"
except Exception as e:
            log_warning(f"[STREAM] start send failed: {e}")

try:
            async for chunk in call_llm_stream_with_fallback(messages, temperature=0.7, model_override=stream_model):
                if time.time() - t_gen > STREAM_TIMEOUT_S:
                    error = True
yield "data: " + json.dumps({"type":"error","message":f"Stream timeout after {STREAM_TIMEOUT_S}s"}) + "\n\n"
log_warning(f"[STREAM] timeout user={user_id}")
break
s = chunk if isinstance(chunk, str) else str(chunk)
if s.startswith("[ERROR]"):
                    error = True
yield "data: " + json.dumps({"type":"error","message":s}) + "\n\n"
break
full += s
yield "data: " + json.dumps({"type":"chunk","content":s}) + "\n\n"
# except Exception as e:  # osierocony except – wyłączony
        error = True
log_warning(f"[STREAM] llm stream failed: {e}")
try:
                yield "data: " + json.dumps({"type":"error","message":str(e)}) + "\n\n"
except Exception:
                pass

        # Complete
durations = {
            "web_ms": 0,
            "gen_ms": int(1000*(time.time()-t_gen)),
            "crit_ms": 0,
            "auto_research_ms": 0,
            "total_ms": int(1000*(time.time()-t_all)),
        }
meta = {
            "streaming": True,
            "user_id": user_id,
            "session_id": session_id,
            "intent_mode": mode,
            "web_used": web_used,
            "web_reason": reason,
            "web_matched_phrase": matched,
            "attachments": attach_stats,
            "facts_count": len(mem_facts),
            "durations_ms": durations
        }

if not error:
            try:
                yield "data: " + json.dumps({"type":"complete","answer":full,"metadata":meta,"sources":sources[:WEB_MAX_RESULTS]}) + "\n\n"
            # --- META: stream log ---
try:
                meta = {
                    "streaming": True,
                    "user_id": user_id,
                    "session_id": session_id,
                    "web_used": web_used,
                    "web_reason": reason,
                    "attachments": attach_stats,
                    "durations_ms": {"total": int(1000*(time.time()-t0))}
                }
log_meta_event(
                    user_id=user_id, session_id=session_id,
                    question=last_user, answer=full,
                    intent=getattr(intent, "mode", "chat"),
                    web_used=web_used, web_reason=reason,
                    complete=True, error=False, timeout=False,
                    durations_ms=meta.get("durations_ms"), model=body.model or None,
                    streaming=True, extra=meta
                )
# except Exception as _e:  # osierocony except – wyłączony
            print(f"[META] stream log failed: {_e}")
# except Exception as e:  # osierocony except – wyłączony
            log_warning(f"[STREAM] complete send failed: {e}")

    # Zapisy rozmowy (po streamie)
try:
            if MEMORY_ENABLED and last_user and full and not error:
                mem_add(user_id=user_id, user_msg=last_user, assistant_msg=full, intent="chat")
except Exception as e:
            log_warning(f"[MEMORY] save failed: {e}")
try:
            if session_id and last_user and full and not error:
                sess_add(session_id, last_user, full, user_attachments=attachments, user_id=user_id)
except Exception as e:
            log_warning(f"[SESSION] save failed: {e}")

        # Self-critique + (opcjonalnie) auto-research → META LOG (asynchronicznie po streamie)
async def _post_meta():
            try:
                crit = await critique_answer(last_user, full, sources)
used_auto = False
refined = False
ar_ms = 0
if AUTO_RESEARCH_ON_STREAM and should_trigger_auto_research(crit):
                    t_ar = time.time()
auto = await auto_research_and_learn(last_user, user_id=user_id)
ar_ms = int(1000*(time.time()-t_ar))
if (auto.get("facts") or []):
                        used_auto = True
durations2 = dict(durations)
durations2["auto_research_ms"] = ar_ms
log_meta_interaction(
                    user_id=user_id,
                    session_id=session_id,
                    request_id=req.headers.get("X-Request-ID"),
                    intent_mode=mode,
                    used_web=bool(web_used),
                    used_auto_research=bool(used_auto),
                    improved_with_facts=bool(refined),
                    critique=crit,
                    durations_ms=durations2,
                    error=None if not error else "stream_error",
                    timeout=False,
                    tokens=None,
                    notes={"stream": True, "web_phrase": matched, "facts_count": len(mem_facts)}
                )
# except Exception as e:  # osierocony except – wyłączony
            log_warning(f"[STREAM][META] post-meta failed: {e}")

try:
            asyncio.create_task(_post_meta())
except Exception:
            pass

return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","Connection":"keep-alive","X-Accel-Buffering":"no"}
    )
@router.post("/api/chat/assistant/stream", summary="Asystent – streaming (SSE)")
async def chat_assistant_stream(body: ChatRequest, req: Request):
    """
    Stabilna wersja streamu. Jeśli dostępny jest call_llm_stream_with_fallback – streamujemy;
    w przeciwnym razie wysyłamy pojedynczy event (fallback).
    """
    import json
    from starlette.responses import StreamingResponse
    try:
        call_llm_stream_with_fallback  # sprawdź czy symbol istnieje
    except NameError:
        call_llm_stream_with_fallback = None  # type: ignore

    def sse(event: str | None, data) -> str:
        head = (f"event: {event}\n" if event else "")
        return head + "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"

    async def _gen():
        try:
            if call_llm_stream_with_fallback is None:
                yield sse(None, {
                    "ok": True,
                    "answer": "Nie mam wystarczającej informacji w lokalnej pamięci.",
                    "sources": [],
                    "metadata": {"source": "hotfix_llm", "raw_finish_reason": "stop", "processing_time": 0}
                })
            else:
                async for chunk in call_llm_stream_with_fallback(body, req):
                    yield sse(None, chunk)
        except Exception as e:  # zabezpieczenie zamiast porwanego except
            yield sse("error", {"error": "stream_error", "detail": str(e)})
        finally:
            yield "event: end\ndata: {}\n\n"

    return StreamingResponse(_gen(), media_type="text/event-stream")
