/**
 * MORDZIX AI - API Client (PHASE 5 - Full Mobile Support)
 * Handles chat, sessions, file upload, and STT endpoints
 */

const API = {
    BASE_URL: '',
    
    /**
     * Get auth token from localStorage
     */
    getToken() {
        return localStorage.getItem('mordzix_auth_token') || '';
    },
    
    /**
     * Set auth token in localStorage
     */
    setToken(token) {
        localStorage.setItem('mordzix_auth_token', token);
    },
    
    /**
     * Get/set current session ID in localStorage (persist across F5)
     */
    getSessionId() {
        return localStorage.getItem('mordzix_session_id') || null;
    },
    
    setSessionId(sessionId) {
        if (sessionId) {
            localStorage.setItem('mordzix_session_id', sessionId);
        } else {
            localStorage.removeItem('mordzix_session_id');
        }
    },
    
    /**
     * Get default headers for API requests
     */
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.getToken()}`
        };
    },
    
    /**
     * Get headers for multipart requests (no Content-Type - browser sets it)
     */
    getMultipartHeaders() {
        return {
            'Authorization': `Bearer ${this.getToken()}`
        };
    },
    
    // =========================================================================
    // SESSIONS API (PHASE 4)
    // =========================================================================
    
    /**
     * List all sessions
     * @returns {Promise<Array>} - Array of session objects
     */
    async listSessions() {
        const url = `${this.BASE_URL}/api/sessions`;
        
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: this.getHeaders()
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] listSessions error:', error);
            throw error;
        }
    },
    
    /**
     * Create a new session
     * @param {string} title - Optional session title
     * @returns {Promise<Object>} - Created session object
     */
    async createSession(title = 'Nowa rozmowa') {
        const url = `${this.BASE_URL}/api/sessions`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify({ title })
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] createSession error:', error);
            throw error;
        }
    },
    
    /**
     * Get a session with its messages
     * @param {string} sessionId - Session UUID
     * @returns {Promise<Object>} - Session object with messages array
     */
    async getSession(sessionId) {
        const url = `${this.BASE_URL}/api/sessions/${sessionId}`;
        
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: this.getHeaders()
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] getSession error:', error);
            throw error;
        }
    },
    
    /**
     * Delete a session
     * @param {string} sessionId - Session UUID
     * @returns {Promise<Object>} - {ok: true, deleted: sessionId}
     */
    async deleteSession(sessionId) {
        const url = `${this.BASE_URL}/api/sessions/${sessionId}`;
        
        try {
            const response = await fetch(url, {
                method: 'DELETE',
                headers: this.getHeaders()
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] deleteSession error:', error);
            throw error;
        }
    },
    
    // =========================================================================
    // CHAT API
    // =========================================================================
    
    /**
     * Send a non-streaming chat message
     * @param {Array} messages - Array of {role, content} objects
     * @param {string} sessionId - Optional session ID
     * @param {Array} attachments - Optional attachments array
     * @returns {Promise<Object>} - Response with {ok, answer, sources, metadata}
     */
    async sendMessage(messages, sessionId = null, attachments = [], webSearch = true) {
        const url = `${this.BASE_URL}/api/chat/assistant`;
        
        try {
            const body = { messages, attachments, web_search: webSearch };
            if (sessionId) {
                body.session_id = sessionId;
            }
            
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(body)
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] sendMessage error:', error);
            throw error;
        }
    },
    
    /**
     * Send a streaming chat message
     * @param {Array} messages - Array of {role, content} objects
     * @param {string} sessionId - Optional session ID
     * @param {Array} attachments - Optional attachments array
     * @param {Function} onChunk - Callback for each chunk: (chunk: string) => void
     * @param {Function} onComplete - Callback when complete: (fullAnswer: string, metadata: Object) => void
     * @param {Function} onError - Callback on error: (error: string) => void
     * @returns {Promise<void>}
     */
    async sendMessageStream(messages, sessionId, attachments, onChunk, onComplete, onError, webSearch = true) {
        const url = `${this.BASE_URL}/api/chat/assistant/stream`;
        
        try {
            const body = { messages, attachments: attachments || [], web_search: webSearch };
            if (sessionId) {
                body.session_id = sessionId;
            }
            
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(body)
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            let fullAnswer = '';
            
            while (true) {
                const { done, value } = await reader.read();
                
                if (done) {
                    break;
                }
                
                buffer += decoder.decode(value, { stream: true });
                
                // Process complete SSE messages
                const lines = buffer.split('\n');
                buffer = lines.pop() || ''; // Keep incomplete line in buffer
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const dataStr = line.slice(6).trim();
                        
                        if (!dataStr) continue;
                        
                        try {
                            const data = JSON.parse(dataStr);
                            
                            switch (data.type) {
                                case 'start':
                                    // Stream started
                                    break;
                                    
                                case 'chunk':
                                    if (data.content) {
                                        fullAnswer += data.content;
                                        onChunk(data.content);
                                    }
                                    break;
                                    
                                case 'complete':
                                    onComplete(data.answer || fullAnswer, data.metadata || {});
                                    break;
                                    
                                case 'error':
                                    onError(data.message || 'Unknown streaming error');
                                    return;
                            }
                        } catch (parseError) {
                            console.warn('[API] Failed to parse SSE data:', dataStr);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('[API] sendMessageStream error:', error);
            onError(error.message || 'Connection error');
        }
    },
    
    /**
     * Check if API is reachable
     * @returns {Promise<boolean>}
     */
    async healthCheck() {
        try {
            const response = await fetch(`${this.BASE_URL}/health`);
            return response.ok;
        } catch {
            return false;
        }
    },
    
    // =========================================================================
    // FILES API
    // =========================================================================
    
    /**
     * Upload files to backend
     * @param {FileList|File[]} files - Files to upload
     * @returns {Promise<Object>} - Response with uploaded file info
     */
    async uploadFiles(files) {
        const url = `${this.BASE_URL}/api/files/upload`;
        
        try {
            const formData = new FormData();
            for (const file of files) {
                formData.append('files', file);
            }
            
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getMultipartHeaders(),
                body: formData
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] uploadFiles error:', error);
            throw error;
        }
    },
    
    // =========================================================================
    // STT API (Speech-to-Text)
    // =========================================================================
    
    /**
     * Transcribe audio file to text
     * @param {Blob} audioBlob - Audio blob from MediaRecorder
     * @param {string} filename - Filename with extension
     * @returns {Promise<Object>} - Response with transcribed text
     */
    async transcribeAudio(audioBlob, filename = 'audio.webm') {
        const url = `${this.BASE_URL}/api/stt/transcribe`;
        
        try {
            const formData = new FormData();
            formData.append('file', audioBlob, filename);
            
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getMultipartHeaders(),
                body: formData
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] transcribeAudio error:', error);
            throw error;
        }
    },
    
    // =========================================================================
    // TTS API (Text-to-Speech)
    // =========================================================================
    
    /**
     * Convert text to speech
     * @param {string} text - Text to convert
     * @param {string} voice - Voice name (adam, rachel, etc.)
     * @returns {Promise<Blob>} - Audio blob (MP3)
     */
    async textToSpeech(text, voice = 'adam') {
        const url = `${this.BASE_URL}/api/tts/speak`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify({ text, voice })
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.blob();
        } catch (error) {
            console.error('[API] textToSpeech error:', error);
            throw error;
        }
    },
    
    /**
     * Get available TTS voices
     * @returns {Promise<Object>} - {ok, available, voices}
     */
    async getTTSVoices() {
        const url = `${this.BASE_URL}/api/tts/voices`;
        
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: this.getHeaders()
            });
            
            return await response.json();
        } catch (error) {
            console.error('[API] getTTSVoices error:', error);
            throw error;
        }
    },
    
    // =========================================================================
    // IMAGE GENERATION API
    // =========================================================================
    
    /**
     * Generate image from prompt
     * @param {string} prompt - Image description
     * @param {Object} options - {negative_prompt, width, height, style}
     * @returns {Promise<Object>} - {ok, url, seed}
     */
    async generateImage(prompt, options = {}) {
        const url = `${this.BASE_URL}/api/images/generate`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify({
                    prompt,
                    negative_prompt: options.negative_prompt || '',
                    width: options.width || 1024,
                    height: options.height || 1024,
                    style: options.style || null
                })
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('[API] generateImage error:', error);
            throw error;
        }
    },
    
    /**
     * Get media services status
     * @returns {Promise<Object>} - {ok, tts, image_generation}
     */
    async getMediaStatus() {
        const url = `${this.BASE_URL}/api/media/status`;
        
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: this.getHeaders()
            });
            
            return await response.json();
        } catch (error) {
            console.error('[API] getMediaStatus error:', error);
            throw error;
        }
    }
};

// Export for use in other modules
window.API = API;
