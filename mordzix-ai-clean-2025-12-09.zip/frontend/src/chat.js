/**
 * MORDZIX AI PRO - Professional Chat UI
 * Commercial Grade Implementation
 * 
 * Features:
 * - Full session management
 * - File attachments with preview
 * - Voice recording (STT) 
 * - Real-time streaming
 * - Context menu
 * - Typing indicators
 * - Theme support
 * - Keyboard shortcuts
 * - Service status monitoring
 */

const Chat = {
    messages: [],
    isStreaming: false,
    isSending: false,
    currentStreamElement: null,
    
    // Session management
    sessions: [],
    currentSessionId: null,
    sessionSearchQuery: '',
    
    // File attachments
    pendingFiles: [],
    uploadedFiles: [],
    
    // Voice recording
    mediaRecorder: null,
    audioChunks: [],
    isRecording: false,
    
    // Stream reconnect
    streamRetryCount: 0,
    maxStreamRetries: 3,
    
    // Settings
    settings: {
        theme: 'dark',
        streamMode: true,
        autoWebSearch: true,
        autoTTS: false,
        ttsVoice: 'adam',
        temperature: 0.7,
        maxTokens: 4096,
        compactMode: false
    },
    
    // DOM Elements
    elements: {
        chatMessages: null,
        messageInput: null,
        sendBtn: null,
        streamToggle: null,
        newChatBtn: null,
        authToken: null,
        saveTokenBtn: null,
        toastContainer: null,
        sessionsList: null,
        sidebar: null,
        sidebarOverlay: null,
        menuToggle: null,
        sidebarClose: null,
        attachBtn: null,
        fileInput: null,
        micBtn: null,
        attachmentsPreview: null,
        sessionSearch: null,
        exportBtn: null,
        welcomeScreen: null,
        typingIndicator: null,
        contextMenu: null
    },
    
    /**
     * Initialize the chat application
     */
    async init() {
        // Get DOM elements
        this.elements.chatMessages = document.getElementById('chatMessages');
        this.elements.messageInput = document.getElementById('messageInput');
        this.elements.sendBtn = document.getElementById('sendBtn');
        this.elements.streamToggle = document.getElementById('streamToggle');
        this.elements.newChatBtn = document.getElementById('newChatBtn');
        this.elements.authToken = document.getElementById('authToken');
        this.elements.saveTokenBtn = document.getElementById('saveTokenBtn');
        this.elements.toastContainer = document.getElementById('toastContainer');
        this.elements.sessionsList = document.getElementById('sessionsList');
        this.elements.sidebar = document.getElementById('sidebar');
        this.elements.sidebarOverlay = document.getElementById('sidebarOverlay');
        this.elements.menuToggle = document.getElementById('menuToggle');
        this.elements.sidebarClose = document.getElementById('sidebarClose');
        this.elements.attachBtn = document.getElementById('attachBtn');
        this.elements.fileInput = document.getElementById('fileInput');
        this.elements.micBtn = document.getElementById('micBtn');
        this.elements.attachmentsPreview = document.getElementById('attachmentsPreview');
        this.elements.sessionSearch = document.getElementById('sessionSearch');
        this.elements.exportBtn = document.getElementById('exportBtn');
        this.elements.welcomeScreen = document.getElementById('welcomeScreen');
        this.elements.typingIndicator = document.getElementById('typingIndicator');
        this.elements.contextMenu = document.getElementById('contextMenu');
        
        // Load settings from localStorage
        this.loadSettings();
        
        // Load saved token
        const savedToken = API.getToken();
        if (savedToken && this.elements.authToken) {
            this.elements.authToken.value = savedToken;
        }
        
        // Restore session ID from localStorage
        const savedSessionId = API.getSessionId();
        if (savedSessionId) {
            this.currentSessionId = savedSessionId;
        }
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Configure marked.js
        this.configureMarked();
        
        // Load sessions and restore current session
        if (savedToken) {
            await this.loadSessions();
            if (this.currentSessionId) {
                await this.restoreSession(this.currentSessionId);
            }
        }
        
        console.log('[Chat] Initialized with full features');
    },
    
    /**
     * Setup all event listeners
     */
    setupEventListeners() {
        // Send button
        this.elements.sendBtn?.addEventListener('click', () => this.sendMessage());
        
        // Enter to send, Shift+Enter for new line
        this.elements.messageInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Auto-resize textarea
        this.elements.messageInput?.addEventListener('input', () => {
            this.autoResizeTextarea();
        });
        
        // New chat button
        this.elements.newChatBtn?.addEventListener('click', () => {
            this.createNewSession();
            this.closeSidebar();
        });
        
        // Save token button
        this.elements.saveTokenBtn?.addEventListener('click', async () => {
            const token = this.elements.authToken?.value.trim();
            if (token) {
                API.setToken(token);
                this.showToast('Token zapisany!', 'success');
                await this.loadSessions();
            }
        });
        
        // Sidebar toggle (mobile)
        this.elements.menuToggle?.addEventListener('click', () => this.openSidebar());
        this.elements.sidebarClose?.addEventListener('click', () => this.closeSidebar());
        this.elements.sidebarOverlay?.addEventListener('click', () => this.closeSidebar());
        
        // File attachment
        this.elements.attachBtn?.addEventListener('click', () => {
            this.elements.fileInput?.click();
        });
        
        this.elements.fileInput?.addEventListener('change', (e) => {
            this.handleFileSelect(e.target.files);
            e.target.value = '';
        });
        
        // Microphone
        this.elements.micBtn?.addEventListener('click', () => this.toggleRecording());
        
        // Session search
        this.elements.sessionSearch?.addEventListener('input', (e) => {
            this.sessionSearchQuery = e.target.value.toLowerCase();
            this.renderSessionsList();
        });
        
        // Export button
        this.elements.exportBtn?.addEventListener('click', () => this.exportConversation());
    },
    
    // =========================================================================
    // SIDEBAR
    // =========================================================================
    
    openSidebar() {
        this.elements.sidebar?.classList.add('open');
        this.elements.sidebarOverlay?.classList.add('active');
        document.body.style.overflow = 'hidden';
    },
    
    closeSidebar() {
        this.elements.sidebar?.classList.remove('open');
        this.elements.sidebarOverlay?.classList.remove('active');
        document.body.style.overflow = '';
    },
    
    // =========================================================================
    // SESSION MANAGEMENT
    // =========================================================================
    
    async loadSessions() {
        if (!this.elements.sessionsList) return;
        
        this.elements.sessionsList.innerHTML = `
            <div class="sessions-group">
                <div class="sessions-group-title">Ładowanie...</div>
                <div class="session-item loading">
                    <span class="session-title">⏳ Pobieranie sesji...</span>
                </div>
            </div>
        `;
        
        try {
            this.sessions = await API.listSessions();
            this.renderSessionsList();
            console.log(`[Chat] Loaded ${this.sessions.length} sessions`);
        } catch (error) {
            console.error('[Chat] Failed to load sessions:', error);
            this.elements.sessionsList.innerHTML = `
                <div class="sessions-group">
                    <div class="sessions-group-title">Błąd</div>
                    <div class="session-item error">
                        Nie udało się załadować sesji
                    </div>
                </div>
            `;
        }
    },
    
    async restoreSession(sessionId) {
        try {
            const session = await API.getSession(sessionId);
            this.currentSessionId = sessionId;
            this.messages = session.messages || [];
            this.renderChatMessages();
            this.renderSessionsList();
            console.log(`[Chat] Restored session: ${sessionId}`);
        } catch (error) {
            console.error('[Chat] Failed to restore session:', error);
            API.setSessionId(null);
            this.currentSessionId = null;
        }
    },
    
    renderSessionsList() {
        if (!this.elements.sessionsList) return;
        
        // Filter sessions by search query
        let filteredSessions = this.sessions;
        if (this.sessionSearchQuery) {
            filteredSessions = this.sessions.filter(s => 
                s.title.toLowerCase().includes(this.sessionSearchQuery)
            );
        }
        
        if (filteredSessions.length === 0) {
            const message = this.sessionSearchQuery 
                ? 'Brak wyników wyszukiwania'
                : 'Kliknij "Nowy chat" aby rozpocząć';
            
            this.elements.sessionsList.innerHTML = `
                <div class="sessions-group">
                    <div class="sessions-group-title">${this.sessionSearchQuery ? 'Wyszukiwanie' : 'Brak sesji'}</div>
                    <div class="session-item empty">${message}</div>
                </div>
            `;
            return;
        }
        
        // Group sessions by date
        const today = new Date().toDateString();
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        
        const groups = { today: [], yesterday: [], older: [] };
        
        filteredSessions.forEach(session => {
            const sessionDate = new Date(session.created_at).toDateString();
            if (sessionDate === today) {
                groups.today.push(session);
            } else if (sessionDate === yesterday) {
                groups.yesterday.push(session);
            } else {
                groups.older.push(session);
            }
        });
        
        let html = '';
        
        if (groups.today.length > 0) {
            html += this.renderSessionGroup('Dzisiaj', groups.today);
        }
        if (groups.yesterday.length > 0) {
            html += this.renderSessionGroup('Wczoraj', groups.yesterday);
        }
        if (groups.older.length > 0) {
            html += this.renderSessionGroup('Starsze', groups.older);
        }
        
        this.elements.sessionsList.innerHTML = html;
        
        // Add click handlers for session items
        this.elements.sessionsList.querySelectorAll('.session-item[data-session-id]').forEach(item => {
            item.addEventListener('click', (e) => {
                // Don't trigger if clicking delete button
                if (e.target.closest('.session-delete')) return;
                
                const sessionId = item.dataset.sessionId;
                if (sessionId) {
                    this.switchToSession(sessionId);
                    this.closeSidebar();
                }
            });
        });
        
        // Add click handlers for delete buttons
        this.elements.sessionsList.querySelectorAll('.session-delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const sessionId = btn.dataset.sessionId;
                if (sessionId) {
                    this.confirmDeleteSession(sessionId);
                }
            });
        });
    },
    
    renderSessionGroup(title, sessions) {
        const items = sessions.map(session => {
            const isActive = session.id === this.currentSessionId;
            return `
                <div class="session-item ${isActive ? 'active' : ''}" data-session-id="${session.id}">
                    <span class="session-title">${this.escapeHtml(session.title)}</span>
                    <button class="session-delete" data-session-id="${session.id}" title="Usuń sesję">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                </div>
            `;
        }).join('');
        
        return `
            <div class="sessions-group">
                <div class="sessions-group-title">${title}</div>
                ${items}
            </div>
        `;
    },
    
    async createNewSession() {
        if (!API.getToken()) {
            this.showToast('Wprowadź token autoryzacji!', 'error');
            return;
        }
        
        try {
            const session = await API.createSession('Nowa rozmowa');
            this.sessions.unshift(session);
            this.currentSessionId = session.id;
            API.setSessionId(session.id);
            this.messages = [];
            this.pendingFiles = [];
            this.uploadedFiles = [];
            this.renderAttachmentsPreview();
            this.renderSessionsList();
            this.renderChatMessages();
            this.showToast('Utworzono nową sesję', 'success');
            this.elements.messageInput?.focus();
            console.log(`[Chat] Created new session: ${session.id}`);
        } catch (error) {
            this.showToast('Błąd tworzenia sesji: ' + error.message, 'error');
        }
    },
    
    async switchToSession(sessionId) {
        if (sessionId === this.currentSessionId) return;
        
        try {
            const session = await API.getSession(sessionId);
            this.currentSessionId = sessionId;
            API.setSessionId(sessionId);
            this.messages = session.messages || [];
            this.pendingFiles = [];
            this.uploadedFiles = [];
            this.renderAttachmentsPreview();
            this.renderSessionsList();
            this.renderChatMessages();
            console.log(`[Chat] Switched to session: ${sessionId}`);
        } catch (error) {
            this.showToast('Błąd ładowania sesji: ' + error.message, 'error');
        }
    },
    
    confirmDeleteSession(sessionId) {
        const session = this.sessions.find(s => s.id === sessionId);
        const title = session ? session.title : 'tej sesji';
        
        if (confirm(`Czy na pewno chcesz usunąć "${title}"?\n\nTa operacja jest nieodwracalna.`)) {
            this.deleteSession(sessionId);
        }
    },
    
    async deleteSession(sessionId) {
        try {
            await API.deleteSession(sessionId);
            
            // Remove from local list
            this.sessions = this.sessions.filter(s => s.id !== sessionId);
            
            // If deleted current session, clear it
            if (sessionId === this.currentSessionId) {
                this.currentSessionId = null;
                API.setSessionId(null);
                this.messages = [];
                this.renderChatMessages();
            }
            
            this.renderSessionsList();
            this.showToast('Sesja usunięta', 'success');
            console.log(`[Chat] Deleted session: ${sessionId}`);
        } catch (error) {
            this.showToast('Błąd usuwania sesji: ' + error.message, 'error');
        }
    },
    
    // =========================================================================
    // EXPORT
    // =========================================================================
    
    exportConversation() {
        if (this.messages.length === 0) {
            this.showToast('Brak wiadomości do eksportu', 'warning');
            return;
        }
        
        const session = this.sessions.find(s => s.id === this.currentSessionId);
        const title = session ? session.title : 'Rozmowa';
        const date = new Date().toISOString().split('T')[0];
        
        let markdown = `# ${title}\n\n`;
        markdown += `*Eksportowano: ${new Date().toLocaleString('pl-PL')}*\n\n---\n\n`;
        
        this.messages.forEach(msg => {
            const role = msg.role === 'user' ? '**Ty:**' : '**Mordzix:**';
            markdown += `${role}\n\n${msg.content}\n\n---\n\n`;
        });
        
        // Download as file
        const blob = new Blob([markdown], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mordzix-${date}-${title.slice(0, 30).replace(/[^a-zA-Z0-9]/g, '_')}.md`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showToast('Rozmowa wyeksportowana', 'success');
    },
    
    // =========================================================================
    // FILE ATTACHMENTS
    // =========================================================================
    
    handleFileSelect(files) {
        if (!files || files.length === 0) return;
        
        for (const file of files) {
            if (file.size > 50 * 1024 * 1024) {
                this.showToast(`Plik "${file.name}" jest za duży (max 50MB)`, 'error');
                continue;
            }
            this.pendingFiles.push(file);
        }
        
        this.renderAttachmentsPreview();
    },
    
    removePendingFile(index) {
        this.pendingFiles.splice(index, 1);
        this.renderAttachmentsPreview();
    },
    
    renderAttachmentsPreview() {
        if (!this.elements.attachmentsPreview) return;
        
        if (this.pendingFiles.length === 0) {
            this.elements.attachmentsPreview.classList.remove('has-files');
            this.elements.attachmentsPreview.innerHTML = '';
            return;
        }
        
        this.elements.attachmentsPreview.classList.add('has-files');
        
        const html = this.pendingFiles.map((file, index) => {
            const isImage = file.type.startsWith('image/');
            
            if (isImage) {
                const url = URL.createObjectURL(file);
                return `
                    <div class="attachment-item">
                        <img src="${url}" class="attachment-thumb" alt="${this.escapeHtml(file.name)}">
                        <button class="attachment-remove" onclick="Chat.removePendingFile(${index})">×</button>
                    </div>
                `;
            } else {
                const ext = file.name.split('.').pop()?.toUpperCase() || 'FILE';
                return `
                    <div class="attachment-item">
                        <div class="attachment-file-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                            </svg>
                            <span>${ext}</span>
                        </div>
                        <button class="attachment-remove" onclick="Chat.removePendingFile(${index})">×</button>
                    </div>
                `;
            }
        }).join('');
        
        this.elements.attachmentsPreview.innerHTML = html;
    },
    
    async uploadPendingFiles() {
        if (this.pendingFiles.length === 0) return [];
        
        try {
            const response = await API.uploadFiles(this.pendingFiles);
            const items = response.items || [];
            this.pendingFiles = [];
            this.renderAttachmentsPreview();
            return items;
        } catch (error) {
            this.showToast('Błąd uploadu plików: ' + error.message, 'error');
            return [];
        }
    },
    
    // =========================================================================
    // VOICE RECORDING
    // =========================================================================
    
    async toggleRecording() {
        if (this.isRecording) {
            this.stopRecording();
        } else {
            await this.startRecording();
        }
    },
    
    async startRecording() {
        // Sprawdź czy przeglądarka obsługuje nagrywanie
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            // Na HTTP (nie HTTPS) mediaDevices nie jest dostępne
            const isSecure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
            if (!isSecure) {
                this.showToast('Mikrofon wymaga HTTPS! Użyj localhost lub włącz SSL.', 'error');
            } else {
                this.showToast('Twoja przeglądarka nie obsługuje nagrywania audio.', 'error');
            }
            return;
        }
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            // Sprawdź obsługiwane formaty
            let mimeType = 'audio/webm';
            if (!MediaRecorder.isTypeSupported('audio/webm')) {
                if (MediaRecorder.isTypeSupported('audio/mp4')) {
                    mimeType = 'audio/mp4';
                } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
                    mimeType = 'audio/ogg';
                }
            }
            
            this.mediaRecorder = new MediaRecorder(stream, { mimeType });
            this.audioChunks = [];
            
            this.mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) {
                    this.audioChunks.push(e.data);
                }
            };
            
            this.mediaRecorder.onstop = async () => {
                stream.getTracks().forEach(track => track.stop());
                
                const audioBlob = new Blob(this.audioChunks, { 
                    type: this.mediaRecorder.mimeType 
                });
                
                await this.processAudioRecording(audioBlob);
            };
            
            this.mediaRecorder.start();
            this.isRecording = true;
            this.elements.micBtn?.classList.add('recording');
            this.showToast('🎤 Nagrywanie... Kliknij ponownie aby zakończyć', 'warning');
            
        } catch (error) {
            console.error('[Chat] Recording error:', error);
            if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
                this.showToast('Brak dostępu do mikrofonu. Zezwól w ustawieniach przeglądarki.', 'error');
            } else if (error.name === 'NotFoundError') {
                this.showToast('Nie znaleziono mikrofonu. Podłącz urządzenie audio.', 'error');
            } else {
                this.showToast('Błąd nagrywania: ' + error.message, 'error');
            }
        }
    },
    
    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            this.elements.micBtn?.classList.remove('recording');
        }
    },
    
    async processAudioRecording(audioBlob) {
        this.showToast('Przetwarzanie nagrania...', 'info');
        
        try {
            const ext = this.mediaRecorder.mimeType.includes('webm') ? 'webm' : 'm4a';
            const response = await API.transcribeAudio(audioBlob, `recording.${ext}`);
            
            const text = response.text || '';
            if (text) {
                const currentText = this.elements.messageInput.value;
                this.elements.messageInput.value = currentText + (currentText ? ' ' : '') + text;
                this.autoResizeTextarea();
                this.elements.messageInput.focus();
                this.showToast('Tekst rozpoznany!', 'success');
            } else {
                this.showToast('Nie udało się rozpoznać mowy', 'warning');
            }
        } catch (error) {
            this.showToast('Błąd STT: ' + error.message, 'error');
        }
    },
    
    // =========================================================================
    // CHAT MESSAGES
    // =========================================================================
    
    configureMarked() {
        if (typeof marked === 'undefined') return;
        
        marked.setOptions({
            highlight: function(code, lang) {
                if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
                    try {
                        return hljs.highlight(code, { language: lang }).value;
                    } catch (e) {}
                }
                return typeof hljs !== 'undefined' ? hljs.highlightAuto(code).value : code;
            },
            breaks: true,
            gfm: true
        });
    },
    
    autoResizeTextarea() {
        const textarea = this.elements.messageInput;
        if (!textarea) return;
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    },
    
    async sendMessage() {
        const content = this.elements.messageInput?.value.trim() || '';
        
        if (this.isStreaming || this.isSending) return;
        if (!content && this.pendingFiles.length === 0) return;
        
        if (!API.getToken()) {
            this.showToast('Wprowadź token autoryzacji w sidebarze!', 'error');
            return;
        }
        
        // Auto-create session if none exists
        if (!this.currentSessionId) {
            try {
                const session = await API.createSession('Nowa rozmowa');
                this.sessions.unshift(session);
                this.currentSessionId = session.id;
                API.setSessionId(session.id);
                this.renderSessionsList();
                console.log(`[Chat] Auto-created session: ${session.id}`);
            } catch (error) {
                this.showToast('Błąd tworzenia sesji: ' + error.message, 'error');
                return;
            }
        }
        
        // Clear input
        if (this.elements.messageInput) {
            this.elements.messageInput.value = '';
            this.autoResizeTextarea();
        }
        
        // Upload pending files
        let uploadedItems = [];
        if (this.pendingFiles.length > 0) {
            uploadedItems = await this.uploadPendingFiles();
        }
        
        // Build message content
        let messageContent = content;
        if (uploadedItems.length > 0) {
            const fileInfo = uploadedItems.map(f => `[Załącznik: ${f.name}]`).join(' ');
            messageContent = messageContent ? `${messageContent}\n\n${fileInfo}` : fileInfo;
        }
        
        // Add user message to UI
        this.addMessage('user', messageContent, uploadedItems);
        
        // Build API messages
        const apiMessages = this.messages.map(m => ({
            role: m.role,
            content: m.content
        }));
        
        const useStream = this.elements.streamToggle?.checked ?? true;
        
        this.isSending = true;
        this.streamRetryCount = 0;
        
        try {
            this.setInputEnabled(false);
            
            const welcome = this.elements.chatMessages?.querySelector('.welcome-message');
            if (welcome) welcome.remove();
            
            if (useStream) {
                await this.sendStreamingMessage(apiMessages, uploadedItems);
            } else {
                await this.sendNonStreamingMessage(apiMessages, uploadedItems);
            }
            
            await this.loadSessions();
        } finally {
            this.isSending = false;
            this.setInputEnabled(true);
            this.elements.messageInput?.focus();
        }
    },
    
    async sendNonStreamingMessage(apiMessages, attachments = []) {
        const placeholder = this.addMessage('assistant', '');
        const bubbleEl = placeholder.querySelector('.message-bubble');
        
        // Show thinking indicator
        bubbleEl.innerHTML = '<div class="thinking-indicator"><span></span><span></span><span></span></div>';
        
        try {
            const response = await API.sendMessage(apiMessages, this.currentSessionId, attachments);
            
            if (response.ok) {
                this.renderMarkdown(bubbleEl, response.answer);
                this.messages[this.messages.length - 1].content = response.answer;
            } else {
                bubbleEl.innerHTML = '<span class="error-text">Przepraszam, wystąpił błąd.</span>';
                this.showToast('Błąd odpowiedzi API', 'error');
            }
        } catch (error) {
            bubbleEl.innerHTML = '<span class="error-text">Błąd połączenia z serwerem.</span>';
            this.showToast(error.message, 'error');
        }
        
        this.scrollToBottom();
    },
    
    async sendStreamingMessage(apiMessages, attachments = []) {
        const messageEl = this.addMessage('assistant', '');
        const bubbleEl = messageEl.querySelector('.message-bubble');
        
        // Show thinking indicator first
        bubbleEl.innerHTML = '<div class="thinking-indicator"><span></span><span></span><span></span></div>';
        
        this.isStreaming = true;
        this.currentStreamElement = bubbleEl;
        
        let fullContent = '';
        let firstChunkReceived = false;
        
        // Get web search toggle state
        const webSearchEnabled = document.getElementById('webSearchToggle')?.checked ?? true;
        
        try {
            await API.sendMessageStream(
                apiMessages,
                this.currentSessionId,
                attachments,
                // onChunk
                (chunk) => {
                    if (!firstChunkReceived) {
                        firstChunkReceived = true;
                        bubbleEl.innerHTML = '';
                        // Add cursor
                        const cursor = document.createElement('span');
                        cursor.className = 'streaming-cursor';
                        bubbleEl.appendChild(cursor);
                    }
                    
                    fullContent += chunk;
                    this.renderStreamingContent(bubbleEl, fullContent);
                    this.scrollToBottom();
                },
                // onComplete
                (answer, metadata) => {
                    this.renderMarkdown(bubbleEl, answer || fullContent);
                    this.messages[this.messages.length - 1].content = answer || fullContent;
                    this.isStreaming = false;
                    this.currentStreamElement = null;
                    this.scrollToBottom();
                },
                // onError
                (error) => {
                    // Try to reconnect
                    if (this.streamRetryCount < this.maxStreamRetries && error.includes('timeout')) {
                        this.streamRetryCount++;
                        this.showToast(`Próba ponownego połączenia (${this.streamRetryCount}/${this.maxStreamRetries})...`, 'warning');
                        setTimeout(() => {
                            this.sendStreamingMessage(apiMessages, attachments);
                        }, 1000);
                        return;
                    }
                    
                    bubbleEl.innerHTML = '<span class="error-text">❌ Błąd: ' + this.escapeHtml(error) + '</span>';
                    this.showToast('Błąd streamingu: ' + error, 'error');
                    this.isStreaming = false;
                    this.currentStreamElement = null;
                    this.setInputEnabled(true);
                },
                webSearchEnabled  // Pass web search toggle state
            );
        } catch (error) {
            bubbleEl.innerHTML = '<span class="error-text">❌ Błąd połączenia z serwerem</span>';
            this.showToast('Nie udało się nawiązać połączenia: ' + error.message, 'error');
            this.isStreaming = false;
            this.currentStreamElement = null;
            this.setInputEnabled(true);
        }
    },
    
    renderStreamingContent(element, content) {
        // Remove cursor if exists
        const cursor = element.querySelector('.streaming-cursor');
        
        // Create text node
        const textNode = document.createTextNode(content);
        element.innerHTML = '';
        element.appendChild(textNode);
        
        // Re-add cursor
        const newCursor = document.createElement('span');
        newCursor.className = 'streaming-cursor';
        element.appendChild(newCursor);
    },
    
    addMessage(role, content, attachments = []) {
        this.messages.push({ role, content, attachments });
        
        const messageEl = document.createElement('div');
        messageEl.className = `message ${role}`;
        
        const avatar = role === 'user' ? 'U' : 'M';
        
        messageEl.innerHTML = `
            <div class="message-avatar">${avatar}</div>
            <div class="message-content">
                ${this.renderAttachmentsHtml(attachments)}
                <div class="message-bubble"></div>
            </div>
        `;
        
        const bubbleEl = messageEl.querySelector('.message-bubble');
        
        if (content) {
            this.renderMarkdown(bubbleEl, content);
        }
        
        this.elements.chatMessages?.appendChild(messageEl);
        this.scrollToBottom();
        
        return messageEl;
    },
    
    renderAttachmentsHtml(attachments) {
        if (!attachments || attachments.length === 0) return '';
        
        const html = attachments.map(att => {
            if (att.kind === 'image' && att.thumb_url) {
                return `
                    <a href="${att.url}" target="_blank" class="message-attachment">
                        <img src="${att.thumb_url}" alt="${this.escapeHtml(att.name)}">
                    </a>
                `;
            } else {
                return `
                    <a href="${att.url}" target="_blank" class="message-attachment-file">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                        </svg>
                        ${this.escapeHtml(att.name)}
                    </a>
                `;
            }
        }).join('');
        
        return `<div class="message-attachments">${html}</div>`;
    },
    
    updateMessage(messageEl, content) {
        const bubbleEl = messageEl.querySelector('.message-bubble');
        if (bubbleEl) {
            this.renderMarkdown(bubbleEl, content);
        }
        this.scrollToBottom();
    },
    
    renderChatMessages() {
        if (!this.elements.chatMessages) return;
        
        this.elements.chatMessages.innerHTML = '';
        
        if (this.messages.length === 0) {
            this.elements.chatMessages.innerHTML = `
                <div class="welcome-message">
                    <h2>Witaj w Mordzix AI</h2>
                    <p>Jestem zaawansowanym asystentem AI. Jak mogę Ci dziś pomóc?</p>
                </div>
            `;
            return;
        }
        
        this.messages.forEach((msg, index) => {
            const messageEl = document.createElement('div');
            messageEl.className = `message ${msg.role}`;
            messageEl.dataset.index = index;
            
            const avatar = msg.role === 'user' ? 'U' : 'M';
            const ttsButton = msg.role === 'assistant' ? `
                <button class="tts-btn" title="Przeczytaj" data-index="${index}">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                        <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                    </svg>
                </button>
            ` : '';
            
            messageEl.innerHTML = `
                <div class="message-avatar">${avatar}</div>
                <div class="message-content">
                    ${this.renderAttachmentsHtml(msg.attachments || [])}
                    <div class="message-bubble"></div>
                    <div class="message-actions">${ttsButton}</div>
                </div>
            `;
            
            const bubbleEl = messageEl.querySelector('.message-bubble');
            this.renderMarkdown(bubbleEl, msg.content);
            
            // TTS button handler
            const ttsBtn = messageEl.querySelector('.tts-btn');
            if (ttsBtn) {
                ttsBtn.addEventListener('click', () => this.speakMessage(msg.content));
            }
            
            this.elements.chatMessages.appendChild(messageEl);
        });
        
        this.scrollToBottom();
    },
    
    renderMarkdown(element, content) {
        if (!element || !content) return;
        
        // Parse markdown
        let html = typeof marked !== 'undefined' ? marked.parse(content) : content;
        
        // Sanitize
        html = typeof DOMPurify !== 'undefined' ? DOMPurify.sanitize(html) : html;
        
        element.innerHTML = html;
        
        // Enhance code blocks
        element.querySelectorAll('pre').forEach(pre => {
            const code = pre.querySelector('code');
            if (!code) return;
            
            const langClass = Array.from(code.classList).find(c => c.startsWith('language-'));
            const lang = langClass ? langClass.replace('language-', '') : 'code';
            
            const header = document.createElement('div');
            header.className = 'code-header';
            header.innerHTML = `
                <span>${lang}</span>
                <button class="copy-btn" onclick="Chat.copyCode(this)">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                    Kopiuj
                </button>
            `;
            
            pre.insertBefore(header, code);
        });
    },
    
    copyCode(button) {
        const pre = button.closest('pre');
        const code = pre?.querySelector('code');
        if (!code) return;
        
        const text = code.textContent;
        
        navigator.clipboard.writeText(text).then(() => {
            button.classList.add('copied');
            button.innerHTML = `
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                Skopiowano!
            `;
            
            setTimeout(() => {
                button.classList.remove('copied');
                button.innerHTML = `
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                    Kopiuj
                `;
            }, 2000);
        });
    },
    
    setInputEnabled(enabled) {
        if (this.elements.messageInput) {
            this.elements.messageInput.disabled = !enabled;
        }
        if (this.elements.sendBtn) {
            this.elements.sendBtn.disabled = !enabled;
        }
    },
    
    scrollToBottom() {
        if (this.elements.chatMessages) {
            this.elements.chatMessages.scrollTop = this.elements.chatMessages.scrollHeight;
        }
    },
    
    showToast(message, type = 'info') {
        if (!this.elements.toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        this.elements.toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 4000);
    },
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    
    // =========================================================================
    // TTS (Text-to-Speech)
    // =========================================================================
    
    currentAudio: null,
    
    async speakMessage(text) {
        if (!text) return;
        
        // Stop current audio if playing
        if (this.currentAudio) {
            this.currentAudio.pause();
            this.currentAudio = null;
        }
        
        // Strip markdown for cleaner speech
        const cleanText = text
            .replace(/```[\s\S]*?```/g, 'blok kodu')
            .replace(/`[^`]+`/g, '')
            .replace(/\*\*([^*]+)\*\*/g, '$1')
            .replace(/\*([^*]+)\*/g, '$1')
            .replace(/#{1,6}\s/g, '')
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            .replace(/!\[([^\]]*)\]\([^)]+\)/g, 'obrazek')
            .trim();
        
        if (!cleanText) {
            this.showToast('Brak tekstu do odczytania', 'warning');
            return;
        }
        
        this.showToast('Generowanie mowy...', 'info');
        
        try {
            const audioBlob = await API.textToSpeech(cleanText.substring(0, 5000), 'adam');
            const audioUrl = URL.createObjectURL(audioBlob);
            
            this.currentAudio = new Audio(audioUrl);
            this.currentAudio.play();
            
            this.currentAudio.onended = () => {
                URL.revokeObjectURL(audioUrl);
                this.currentAudio = null;
            };
            
            this.showToast('Odtwarzanie...', 'success');
        } catch (error) {
            this.showToast('Błąd TTS: ' + error.message, 'error');
        }
    },
    
    // =========================================================================
    // IMAGE GENERATION
    // =========================================================================
    
    async generateImage(prompt) {
        if (!prompt) return;
        
        this.showToast('Generowanie obrazu...', 'info');
        
        try {
            const result = await API.generateImage(prompt);
            
            if (result.ok && result.url) {
                // Add image to chat as assistant message
                const imageHtml = `Wygenerowałem obraz:\n\n![Generated Image](${result.url})`;
                this.addMessage('assistant', imageHtml);
                this.messages.push({ role: 'assistant', content: imageHtml });
                this.showToast('Obraz wygenerowany!', 'success');
            } else {
                this.showToast('Nie udało się wygenerować obrazu', 'error');
            }
        } catch (error) {
            this.showToast('Błąd generowania: ' + error.message, 'error');
        }
    },
    
    // =========================================================================
    // QUICK ACTIONS
    // =========================================================================
    
    handleQuickAction(action) {
        switch(action) {
            case 'search':
                this.elements.messageInput.value = 'Szukaj w internecie: ';
                this.elements.messageInput.focus();
                break;
            case 'image':
                this.openImageModal();
                break;
            case 'code':
                this.elements.messageInput.value = 'Napisz kod: ';
                this.elements.messageInput.focus();
                break;
            case 'analyze':
                this.elements.messageInput.value = 'Przeanalizuj tekst pod kątem NLP: ';
                this.elements.messageInput.focus();
                break;
        }
    },
    
    // =========================================================================
    // SETTINGS MODAL
    // =========================================================================
    
    openSettings() {
        document.getElementById('settingsModal')?.classList.add('active');
        this.loadServicesStatus();
    },
    
    closeSettings() {
        document.getElementById('settingsModal')?.classList.remove('active');
    },
    
    async loadServicesStatus() {
        const container = document.getElementById('servicesStatus');
        if (!container) return;
        
        const services = [
            { name: 'API', endpoint: '/health' },
            { name: 'TTS (ElevenLabs)', endpoint: '/api/tts/voices' },
            { name: 'Image Gen', endpoint: '/api/media/status' },
            { name: 'Memory', endpoint: '/api/memory/status' },
            { name: 'NLP', endpoint: '/api/nlp/stats' }
        ];
        
        container.innerHTML = '';
        
        for (const service of services) {
            const online = await this.checkServiceStatus(service.endpoint);
            container.innerHTML += `
                <div class="service-item">
                    <span class="service-dot ${online ? 'online' : 'offline'}"></span>
                    <span>${service.name}</span>
                </div>
            `;
        }
    },
    
    async checkServiceStatus(endpoint) {
        try {
            const response = await fetch(endpoint + '?token=' + API.getToken(), {
                headers: { 'Authorization': 'Bearer ' + API.getToken() }
            });
            return response.ok;
        } catch {
            return false;
        }
    },
    
    // =========================================================================
    // IMAGE MODAL
    // =========================================================================
    
    openImageModal() {
        document.getElementById('imageModal')?.classList.add('active');
        document.getElementById('imagePrompt')?.focus();
    },
    
    closeImageModal() {
        document.getElementById('imageModal')?.classList.remove('active');
        document.getElementById('imagePreview').innerHTML = '';
    },
    
    async generateImageFromModal() {
        const prompt = document.getElementById('imagePrompt')?.value;
        const style = document.getElementById('imageStyle')?.value;
        const size = document.getElementById('imageSize')?.value || '1024x1024';
        
        if (!prompt) {
            this.showToast('Wpisz opis obrazu', 'error');
            return;
        }
        
        const preview = document.getElementById('imagePreview');
        preview.innerHTML = '<div class="loading">Generowanie...</div>';
        
        try {
            const fullPrompt = style ? `${prompt}, ${style} style` : prompt;
            const result = await API.generateImage(fullPrompt, size);
            
            if (result.ok && result.url) {
                preview.innerHTML = `<img src="${result.url}" alt="${prompt}">`;
                this.showToast('Obraz wygenerowany!', 'success');
            } else {
                preview.innerHTML = '<div class="loading">Błąd generowania</div>';
                this.showToast('Nie udało się wygenerować', 'error');
            }
        } catch (error) {
            preview.innerHTML = '<div class="loading">Błąd: ' + error.message + '</div>';
        }
    },
    
    // =========================================================================
    // SETTINGS
    // =========================================================================
    
    loadSettings() {
        const saved = localStorage.getItem('mordzix_settings');
        if (saved) {
            try {
                this.settings = { ...this.settings, ...JSON.parse(saved) };
            } catch (e) {}
        }
        this.applySettings();
    },
    
    saveSettings() {
        localStorage.setItem('mordzix_settings', JSON.stringify(this.settings));
    },
    
    applySettings() {
        // Theme
        document.documentElement.setAttribute('data-theme', this.settings.theme);
        
        // Compact mode
        if (this.settings.compactMode) {
            document.body.classList.add('compact');
        }
    },
    
    setTheme(theme) {
        if (theme === 'auto') {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            theme = prefersDark ? 'dark' : 'light';
        }
        this.settings.theme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        this.saveSettings();
        
        // Update icon
        const icon = document.querySelector('#themeToggleBtn i');
        if (icon) {
            icon.setAttribute('data-lucide', theme === 'dark' ? 'moon' : 'sun');
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    },
    
    // =========================================================================
    // TYPING INDICATOR
    // =========================================================================
    
    showTyping() {
        this.elements.typingIndicator?.classList.add('active');
        this.scrollToBottom();
    },
    
    hideTyping() {
        this.elements.typingIndicator?.classList.remove('active');
    },
    
    // =========================================================================
    // WELCOME SCREEN
    // =========================================================================
    
    hideWelcome() {
        if (this.elements.welcomeScreen) {
            this.elements.welcomeScreen.style.display = 'none';
        }
    },
    
    showWelcome() {
        if (this.elements.welcomeScreen && this.messages.length === 0) {
            this.elements.welcomeScreen.style.display = 'flex';
        }
    },
    
    // =========================================================================
    // CONTEXT MENU
    // =========================================================================
    
    showContextMenu(e, messageIndex) {
        e.preventDefault();
        const menu = this.elements.contextMenu;
        if (!menu) return;
        
        menu.dataset.messageIndex = messageIndex;
        menu.style.left = e.pageX + 'px';
        menu.style.top = e.pageY + 'px';
        menu.classList.add('active');
        
        // Close on click outside
        setTimeout(() => {
            document.addEventListener('click', this.hideContextMenu.bind(this), { once: true });
        }, 10);
    },
    
    hideContextMenu() {
        this.elements.contextMenu?.classList.remove('active');
    },
    
    handleContextAction(action) {
        const index = parseInt(this.elements.contextMenu?.dataset.messageIndex);
        const message = this.messages[index];
        if (!message) return;
        
        switch(action) {
            case 'copy':
                navigator.clipboard.writeText(message.content);
                this.showToast('Skopiowano!', 'success');
                break;
            case 'speak':
                this.speakMessage(message.content);
                break;
            case 'regenerate':
                if (message.role === 'assistant' && index > 0) {
                    const userMsg = this.messages[index - 1];
                    if (userMsg?.role === 'user') {
                        this.messages.splice(index, 1);
                        this.renderMessages();
                        this.sendMessage(userMsg.content);
                    }
                }
                break;
            case 'delete':
                this.messages.splice(index, 1);
                this.renderMessages();
                this.showToast('Usunięto wiadomość', 'success');
                break;
        }
        this.hideContextMenu();
    },
    
    // =========================================================================
    // SERVICES STATUS
    // =========================================================================
    
    async loadServicesStatus() {
        const container = document.getElementById('servicesStatus');
        if (!container) return;
        
        const services = [
            { name: 'Chat API', endpoint: '/health' },
            { name: 'TTS', endpoint: '/api/tts/voices' },
            { name: 'Images', endpoint: '/api/media/status' },
            { name: 'Memory', endpoint: '/api/memory/status' },
            { name: 'NLP', endpoint: '/api/nlp/stats' },
            { name: 'Search', endpoint: '/api/research/sources' }
        ];
        
        container.innerHTML = '';
        
        for (const service of services) {
            const online = await this.checkService(service.endpoint);
            container.innerHTML += `
                <div class="service-item">
                    <span class="service-dot ${online ? 'online' : 'offline'}"></span>
                    <span>${service.name}</span>
                </div>
            `;
        }
    },
    
    async checkService(endpoint) {
        try {
            const r = await fetch(endpoint + '?token=' + API.getToken(), {
                headers: { 'Authorization': 'Bearer ' + API.getToken() },
                signal: AbortSignal.timeout(3000)
            });
            return r.ok;
        } catch {
            return false;
        }
    },
    
    // =========================================================================
    // UTILITY
    // =========================================================================
    
    scrollToBottom() {
        if (this.elements.chatMessages) {
            this.elements.chatMessages.scrollTop = this.elements.chatMessages.scrollHeight;
        }
    },
    
    formatTime(date) {
        return new Intl.DateTimeFormat('pl', { 
            hour: '2-digit', 
            minute: '2-digit' 
        }).format(date || new Date());
    },
    
    reinitIcons() {
        if (typeof lucide !== 'undefined') {
            setTimeout(() => lucide.createIcons(), 10);
        }
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    Chat.init();
    
    // Settings Modal
    document.getElementById('settingsBtn')?.addEventListener('click', () => Chat.openSettings());
    document.getElementById('closeSettings')?.addEventListener('click', () => Chat.closeSettings());
    document.getElementById('settingsModal')?.addEventListener('click', (e) => {
        if (e.target.id === 'settingsModal') Chat.closeSettings();
    });
    
    // Theme select
    document.getElementById('themeSelect')?.addEventListener('change', (e) => {
        Chat.setTheme(e.target.value);
    });
    
    // Image Modal
    document.getElementById('closeImageModal')?.addEventListener('click', () => Chat.closeImageModal());
    document.getElementById('imageModal')?.addEventListener('click', (e) => {
        if (e.target.id === 'imageModal') Chat.closeImageModal();
    });
    document.getElementById('generateImageBtn')?.addEventListener('click', () => Chat.generateImageFromModal());
    
    // Context menu actions
    document.querySelectorAll('.context-item').forEach(item => {
        item.addEventListener('click', () => {
            Chat.handleContextAction(item.dataset.action);
        });
    });
    
    // Close context menu on scroll
    document.getElementById('chatMessages')?.addEventListener('scroll', () => {
        Chat.hideContextMenu();
    });
    
    // Reinitialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});

// Export for global access
window.Chat = Chat;
