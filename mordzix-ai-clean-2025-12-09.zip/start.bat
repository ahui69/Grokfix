@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    MORDZIX AI PRO 6.0                        ║
echo ║══════════════════════════════════════════════════════════════║
echo ║  Tryby:  Tech  Sport  Moda/Vinted  HVAC  Legal               ║
echo ║  Features: Memory  WebSearch  Images  Files                  ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found! Install Python 3.10+
    pause
    exit /b 1
)

:: Create venv if not exists
if not exist .venv (
    echo [+] Creating virtual environment...
    python -m venv .venv
)

:: Activate venv
call .venv\Scripts\activate.bat

:: Quick dependency check (skip if recently installed)
if not exist .venv\.deps_installed (
    echo [+] Installing dependencies...
    pip install -r requirements.txt -q
    echo. > .venv\.deps_installed
) else (
    echo [+] Dependencies OK
)

:: Create uploads directory
if not exist uploads mkdir uploads

:: Start server
echo.
echo [START] Server: http://0.0.0.0:8080
echo [START] Docs: http://localhost:8080/docs
echo [START] Admin: http://localhost:8080/admin
echo.

python main.py

pause
