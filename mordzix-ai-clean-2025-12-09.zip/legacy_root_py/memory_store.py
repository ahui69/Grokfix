"""
Legacy shim – stare endpointy psyche korzystają z legacy_root_py.memory_store.
Przekierowujemy na nowy core.memory_store.
"""
from core.memory_store import *  # noqa: F401,F403
