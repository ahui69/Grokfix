# -*- coding: utf-8 -*-
"""
Legacy bridge: legacy_root_py.security -> core.security
Z dodatkiem funkcji _auth, której oczekują stare endpointy psyche.
"""

from core.security import *  # type: ignore  # noqa

try:
    from core.security import verify_token  # type: ignore
except Exception:  # fallback jakby coś się zmieniło
    verify_token = None  # type: ignore


def _auth(*args, **kwargs):
    """
    Legacy alias – część starych modułów woła _auth(...)
    Zwraca wynik verify_token, a jak go nie ma – None (ale nie sypie wyjątkami).
    """
    if verify_token is None:
        return None
    try:
        return verify_token(*args, **kwargs)  # type: ignore[misc]
    except Exception:
        return None
