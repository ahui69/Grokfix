# -*- coding: utf-8 -*-
"""
Legacy wrapper – stare moduły korzystają z legacy_root_py.advanced_llm,
więc przekierowujemy wszystko do core.advanced_llm.
"""

from __future__ import annotations

from typing import Any, Dict

from core.advanced_llm import (  # type: ignore
    is_initialized,
    ensure_initialized,
    call_advanced_llm,
    aask,
)

__all__ = [
    "is_initialized",
    "ensure_initialized",
    "call_advanced_llm",
    "aask",
]
