#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Legacy LLM wrapper.

Stare moduły z legacy_root_py korzystają z:
- call_llm
- call_llm_stream
- call_llm_raw
- get_llm_client
itd.

Tutaj wszystko delegujemy do core.llm, żeby nie dłubać
w kilkunastu starych plikach.
"""

from __future__ import annotations

from typing import Any, Dict, List

from core.llm import (
    call_llm as core_call_llm,
    call_llm_stream as core_call_llm_stream,
    call_llm_raw as core_call_llm_raw,
    stream_llm as core_stream_llm,
    chat_with_context as core_chat_with_context,
    llm_health as core_llm_health,
    get_llm_client as core_get_llm_client,
)


def call_llm(messages: List[dict], **opts: Any) -> str:
    return core_call_llm(messages, **opts)


def call_llm_stream(messages: List[dict], **opts: Any):
    return core_call_llm_stream(messages, **opts)


def call_llm_raw(messages: List[dict], **opts: Any) -> Dict[str, Any]:
    return core_call_llm_raw(messages, **opts)


def stream_llm(messages: List[dict], **opts: Any):
    return core_stream_llm(messages, **opts)


def chat_with_context(*, user_content: str, **kwargs: Any) -> str:
    return core_chat_with_context(user_content=user_content, **kwargs)


def llm_health() -> Dict[str, Any]:
    return core_llm_health()


def get_llm_client():
    return core_get_llm_client()


__all__ = [
    "call_llm",
    "call_llm_stream",
    "call_llm_raw",
    "stream_llm",
    "chat_with_context",
    "llm_health",
    "get_llm_client",
]
