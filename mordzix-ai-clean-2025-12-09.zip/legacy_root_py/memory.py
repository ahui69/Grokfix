"""
Legacy shim – stare moduły odwołują się do legacy_root_py.memory.
Tutaj przekierowujemy wszystko do core.memory.
"""
from core.memory import *  # noqa: F401,F403
