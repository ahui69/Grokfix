from fastapi import FastAPI, APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Dict, Any, Optional
import os, httpx, re, json

app = FastAPI(title="FF Sidecar Proxy", version="1.0")
router = APIRouter(prefix="/api/ff", tags=["ff-proxy"])

ALLOWED_PREFIXES=[p.strip() for p in os.getenv("FF_ALLOWED_PREFIXES","/api/").split(",") if p.strip()]
DENY=[r"^/api/ff/.*", r"^/docs$", r"^/redoc$", r"^/openapi\\.json$"]
INTERNAL=os.getenv("INTERNAL_BASE_URL","http://127.0.0.1:8080")

class ProxyReq(BaseModel):
    method:str
    path:str
    query: Optional[Dict[str, Any]]=None
    body:  Optional[Any]=None
    headers: Optional[Dict[str,str]]=None

def allowed(path:str)->bool:
    return (all(not re.match(p,path) for p in DENY)
            and any(path.startswith(pref) for pref in ALLOWED_PREFIXES))

@router.post("/proxy")
async def proxy(req: ProxyReq, http: Request):
    if not allowed(req.path):
        raise HTTPException(403, f"path not allowed: {req.path}")
    headers={}
    if (auth:=http.headers.get("authorization")): headers["authorization"]=auth
    if req.headers: headers.update(req.headers)
    url=f"{INTERNAL}{req.path}"
    async with httpx.AsyncClient(timeout=60.0) as c:
        r=await c.request(req.method.upper(), url, headers=headers,
                          params=req.query or {},
                          json=req.body if isinstance(req.body,(dict,list)) else None,
                          content=req.body.encode() if isinstance(req.body,str) else None)
    ct=(r.headers.get("content-type") or "").lower()
    try: out = r.json() if "application/json" in ct else r.text
    except: out = r.text
    if r.status_code>=400: raise HTTPException(r.status_code, detail=out)
    return out

app.include_router(router)
