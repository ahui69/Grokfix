# Legacy shim – re-eksportuje główną konfigurację Mordzixa
from core.config import *  # noqa: F401,F403
