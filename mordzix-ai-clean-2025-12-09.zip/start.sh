#!/usr/bin/env bash
set -euo pipefail

### ─────────────────────────────────────────────────────────
### USTAWIENIA
### ─────────────────────────────────────────────────────────
APP_NAME="Mordzix AI"
APP_DIR="${APP_DIR:-/root/mordzix-ai}"
VENV_DIR="${VENV_DIR:-$APP_DIR/.venv}"
SERVICE_NAME="mordzix"
PORT="${PORT:-8080}"
HOST="${HOST:-0.0.0.0}"
PY_BIN="${PY_BIN:-python3}"
PIP_BIN="${PIP_BIN:-pip3}"
ENV_FILE="$APP_DIR/.env"
REQ_FILE="$APP_DIR/requirements.txt"

### ─────────────────────────────────────────────────────────
### FUNKCJE POMOCNICZE
### ─────────────────────────────────────────────────────────
log()  { printf "\033[1;32m[*]\033[0m %s\n" "$*"; }
warn() { printf "\033[1;33m[!]\033[0m %s\n" "$*"; }
err()  { printf "\033[1;31m[x]\033[0m %s\n" "$*" >&2; }
die()  { err "$*"; exit 1; }

need_root() {
  if [[ $EUID -ne 0 ]]; then
    die "Uruchom jako root (sudo)."
  fi
}

detect_pkg_mgr() {
  if command -v apt-get >/dev/null 2>&1; then echo apt; return; fi
  if command -v dnf >/dev/null 2>&1; then echo dnf; return; fi
  if command -v yum >/dev/null 2>&1; then echo yum; return; fi
  echo none
}

install_system_deps() {
  local pm; pm=$(detect_pkg_mgr)
  case "$pm" in
    apt)
      log "Instaluję pakiety systemowe (APT)…"
      export DEBIAN_FRONTEND=noninteractive
      apt-get update -y
      # psmisc → fuser; + lsof/ss, python venv, redis, narzędzia
      apt-get install -y \
        psmisc lsof procps iproute2 \
        curl jq git \
        python3 python3-venv python3-pip build-essential \
        sqlite3 redis-server \
        libmagic1
      systemctl enable redis-server >/dev/null 2>&1 || true
      systemctl start  redis-server >/dev/null 2>&1 || true
      ;;
    dnf|yum)
      log "Instaluję pakiety systemowe ($pm)…"
      $pm -y install \
        psmisc lsof procps-ng iproute \
        curl jq git \
        python3 python3-venv python3-pip @development-tools \
        sqlite redis libmagic
      systemctl enable redis >/dev/null 2>&1 || true
      systemctl start  redis >/dev/null 2>&1 || true
      ;;
    *)
      warn "Nie rozpoznano menedżera pakietów — pomijam instalację systemowych deps."
      ;;
  esac
}

kill_port() {
  local port="$1"
  log "Czyszczę port :$port (ubijam stare procesy)…"
  if command -v fuser >/dev/null 2>&1; then
    fuser -k "${port}/tcp" >/dev/null 2>&1 || true
  fi
  # fallbacki
  if command -v lsof >/dev/null 2>&1; then
    lsof -ti tcp:"$port" | xargs -r kill -9 || true
  fi
  if command -v ss >/dev/null 2>&1; then
    ss -lptn 'sport = :'$port'' 2>/dev/null | awk 'NR>1{print $7}' | sed 's/.*pid=\([0-9]\+\).*/\1/' | xargs -r kill -9 || true
  fi
}

create_venv() {
  log "Tworzę/odświeżam venv…"
  mkdir -p "$APP_DIR"
  cd "$APP_DIR"
  if [[ ! -d "$VENV_DIR" ]]; then
    "$PY_BIN" -m venv "$VENV_DIR"
  fi
  # shellcheck disable=SC1090
  source "$VENV_DIR/bin/activate"
  python -m pip install --upgrade pip wheel setuptools
  if [[ -f "$REQ_FILE" ]]; then
    log "Instaluję zależności z requirements.txt…"
    pip install -r "$REQ_FILE"
  else
    warn "Brak requirements.txt — instaluję sprawdzony zestaw minimalny."
    pip install \
      uvicorn fastapi pydantic httpx python-dotenv redis \
      pillow python-docx PyMuPDF \
      starlette
  fi
}

check_env() {
  if [[ ! -f "$ENV_FILE" ]]; then
    die "Brak $ENV_FILE — nie będę tworzyć placeholderów. Dodaj swój .env i uruchom ponownie."
  fi
  # Szybka walidacja kluczowych pozycji:
  if ! grep -q '^AUTH_TOKEN=' "$ENV_FILE"; then
    die "W .env brak AUTH_TOKEN — bez tego API odrzuci żądania."
  fi
  if ! grep -q '^OPENAI_BASE_URL=\|^LLM_BASE_URL=' "$ENV_FILE"; then
    warn "W .env brak LLM_* / OPENAI_* — zakładam, że core/llm.py i DeepInfra masz już ustawione."
  fi
}

write_service() {
  local svc="/etc/systemd/system/${SERVICE_NAME}.service"
  if [[ -f "$svc" && "${FORCE_SERVICE:-0}" != "1" ]]; then
    log "Service już istnieje: $svc (pomiń/pozostań). Użyj FORCE_SERVICE=1, aby nadpisać."
    return
  fi
  log "Zapisuję systemd unit: $svc"
  cat > "$svc" <<UNIT
[Unit]
Description=$APP_NAME
After=network-online.target redis-server.service
Wants=network-online.target
Requires=redis-server.service

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$VENV_DIR/bin/python $APP_DIR/main.py
Restart=always
RestartSec=2
LimitNOFILE=65535
TimeoutStartSec=120

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
}

start_service() {
  log "Zatrzymuję starą usługę (jeśli działa)…"
  systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true
  kill_port "$PORT"
  log "Startuję usługę $SERVICE_NAME…"
  systemctl start "$SERVICE_NAME"
}

healthcheck() {
  log "Health-check /status…"
  for i in {1..30}; do
    sleep 1
    if curl -s "http://127.0.0.1:${PORT}/status" | jq -e '.ok==true' >/dev/null 2>&1; then
      curl -s "http://127.0.0.1:${PORT}/status" | jq .
      return 0
    fi
  done
  err "Health-check nie przeszedł. Ostatnie logi:"
  journalctl -u "$SERVICE_NAME".service -n 80 --no-pager
  return 1
}

quick_api_selftest() {
  log "Szybkie testy API…"
  local AUTH
  AUTH="$(awk -F= '/^AUTH_TOKEN=/{print $2}' "$ENV_FILE" | tr -d '\r')"
  local BASE="http://127.0.0.1:${PORT}"

  # /status
  curl -s "$BASE/status" | jq -r '.version // "?"' >/dev/null || die "Brak /status"

  # sesja
  local SID
  SID="$(curl -s -X POST "$BASE/api/sessions" -H "Authorization: Bearer $AUTH" -H 'Content-Type: application/json' -d '{"title":"selftest"}' | jq -r '.id')"
  [[ -n "$SID" && "$SID" != "null" ]] || die "Nie utworzono sesji"

  # memory.add
  curl -s -X POST "$BASE/api/memory/add" \
    -H "Authorization: Bearer $AUTH" -H 'Content-Type: application/json' \
    -d "{\"session_id\":\"$SID\",\"text\":\"SELFTEST OK\",\"tags\":[\"self\",\"ok\"]}" \
    | jq -e '.text=="OK"' >/dev/null || die "memory.add fail"

  # memory.search
  curl -s -X POST "$BASE/api/memory/search" \
    -H "Authorization: Bearer $AUTH" -H 'Content-Type: application/json' \
    -d "{\"session_id\":\"$SID\",\"q\":\"SELFTEST\",\"limit\":3}" \
    | jq -e '.text|contains("Znaleziono")' >/dev/null || die "memory.search fail"

  # chat ping (bez weba)
  curl -s -X POST "$BASE/api/chat/assistant" \
    -H "Authorization: Bearer $AUTH" -H 'Content-Type: application/json' \
    -d "{\"session_id\":\"$SID\",\"internet_allowed\":false,\"use_research\":false,\"messages\":[{\"role\":\"user\",\"content\":\"Napisz dokładnie słowo: PONG\"}]}" \
    | jq -e '.ok==true' >/dev/null || warn "chat/assistant odpowiedział inaczej niż OK (sprawdź model/kod)."

  log "Self-test skończony."
}

### ─────────────────────────────────────────────────────────
### GŁÓWNY PRZEBIEG
### ─────────────────────────────────────────────────────────
need_root
[[ -d "$APP_DIR" ]] || die "Nie ma katalogu projektu: $APP_DIR"

install_system_deps
check_env
create_venv
write_service
start_service
healthcheck
quick_api_selftest

log "Gotowe. Przydatne komendy:"
echo "  journalctl -u ${SERVICE_NAME}.service -n 100 -f"
echo "  systemctl restart ${SERVICE_NAME}.service"
echo "  curl -s http://127.0.0.1:${PORT}/status | jq ."
