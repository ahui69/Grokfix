# MORDZIX API – manifest endpointów

- Łącznie endpointów: **155**


## Grupy

### `admin`  (5 endpointów)

- `/api/admin/cache/clear`
- `/api/admin/cache/stats`
- `/api/admin/jwt/rotate`
- `/api/admin/ratelimit/config`
- `/api/admin/ratelimit/usage/{user_id}`

### `automation`  (1 endpointów)

- `/api/automation/status`

### `autoroute`  (4 endpointów)

- `/api/autoroute/analyze`
- `/api/autoroute/endpoints`
- `/api/autoroute/execute`
- `/api/autoroute/stats`

### `batch`  (4 endpointów)

- `/api/batch/metrics`
- `/api/batch/process`
- `/api/batch/shutdown`
- `/api/batch/submit`

### `captcha`  (2 endpointów)

- `/api/captcha/balance`
- `/api/captcha/solve`

### `chat`  (3 endpointów)

- `/api/chat/assistant`
- `/api/chat/assistant/stream`
- `/api/chat/auto`

### `code`  (14 endpointów)

- `/api/code/deps/install`
- `/api/code/docker/build`
- `/api/code/docker/run`
- `/api/code/exec`
- `/api/code/format`
- `/api/code/git`
- `/api/code/init`
- `/api/code/lint`
- `/api/code/plan`
- `/api/code/read`
- `/api/code/snapshot`
- `/api/code/test`
- `/api/code/tree`
- `/api/code/write`

### `cognitive`  (10 endpointów)

- `/api/cognitive/nlp/analyze`
- `/api/cognitive/proactive/suggestions`
- `/api/cognitive/process`
- `/api/cognitive/psychology/analyze`
- `/api/cognitive/psychology/state/{user_id}`
- `/api/cognitive/reflect`
- `/api/cognitive/reflection/summary`
- `/api/cognitive/semantic/analyze`
- `/api/cognitive/status`
- `/api/cognitive/tools/list`

### `endpoints`  (1 endpointów)

- `/api/endpoints/list`

### `fashion`  (7 endpointów)

- `/api/fashion/categories`
- `/api/fashion/detect-brand`
- `/api/fashion/forecast-trends`
- `/api/fashion/generate-outfit`
- `/api/fashion/occasions`
- `/api/fashion/stats`
- `/api/fashion/weather-types`

### `ff`  (1 endpointów)

- `/api/ff/proxy`

### `files`  (11 endpointów)

- `/api/files/analyze`
- `/api/files/batch/analyze`
- `/api/files/delete`
- `/api/files/download`
- `/api/files/list`
- `/api/files/stats`
- `/api/files/thumb/{tenant}/{day}/{name}`
- `/api/files/upload`
- `/api/files/upload/base64`
- `/api/files/{tenant}/{day}/{name}`

### `hacker`  (6 endpointów)

- `/api/hacker/exploit/sqli`
- `/api/hacker/exploits/list`
- `/api/hacker/recon/domain`
- `/api/hacker/scan/ports`
- `/api/hacker/scan/vulnerabilities`
- `/api/hacker/tools/status`

### `image`  (2 endpointów)

- `/api/image/file/{tenant}/{name}`
- `/api/image/generate`

### `internal`  (2 endpointów)

- `/api/internal/ui`
- `/api/internal/ui_token`

### `lang`  (1 endpointów)

- `/api/lang/detect`

### `memory`  (6 endpointów)

- `/api/memory/add`
- `/api/memory/export`
- `/api/memory/import`
- `/api/memory/optimize`
- `/api/memory/search`
- `/api/memory/status`

### `ml`  (5 endpointów)

- `/api/ml/model-info`
- `/api/ml/predict-suggestions`
- `/api/ml/record-feedback`
- `/api/ml/retrain`
- `/api/ml/stats`

### `nlp`  (8 endpointów)

- `/api/nlp/analyze`
- `/api/nlp/batch-analyze`
- `/api/nlp/entities`
- `/api/nlp/extract-topics`
- `/api/nlp/key-phrases`
- `/api/nlp/readability`
- `/api/nlp/sentiment`
- `/api/nlp/stats`

### `prometheus`  (3 endpointów)

- `/api/prometheus/health`
- `/api/prometheus/metrics`
- `/api/prometheus/stats`

### `psyche`  (5 endpointów)

- `/api/psyche`
- `/api/psyche/history`
- `/api/psyche/reset`
- `/api/psyche/state`

### `research`  (4 endpointów)

- `/api/research/autonauka`
- `/api/research/search`
- `/api/research/sources`
- `/api/research/test`

### `search`  (5 endpointów)

- `/api/search/compare`
- `/api/search/hybrid`
- `/api/search/stats`
- `/api/search/test`
- `/api/search/widget`

### `stt`  (4 endpointów)

- `/api/stt/file/{tenant}/{name}`
- `/api/stt/providers`
- `/api/stt/transcribe`

### `suggestions`  (4 endpointów)

- `/api/suggestions/analyze`
- `/api/suggestions/generate`
- `/api/suggestions/inject`
- `/api/suggestions/stats`

### `travel`  (6 endpointów)

- `/api/travel/attractions/{city}`
- `/api/travel/geocode`
- `/api/travel/hotels/{city}`
- `/api/travel/restaurants/{city}`
- `/api/travel/search`
- `/api/travel/trip-plan`

### `tts`  (2 endpointów)

- `/api/tts/speak`
- `/api/tts/voices`

### `vision`  (2 endpointów)

- `/api/vision/describe`
- `/api/vision/ocr`

### `voice`  (2 endpointów)

- `/api/voice/file/{tenant}/{name}`
- `/api/voice/tts`

### `writer`  (13 endpointów)

- `/api/writer/article/masterpiece`
- `/api/writer/auction/knowledge`
- `/api/writer/auction/learn`
- `/api/writer/auction/pro`
- `/api/writer/auction/tags`
- `/api/writer/creative`
- `/api/writer/fashion/analyze`
- `/api/writer/product`
- `/api/writer/sales/masterpiece`
- `/api/writer/social`
- `/api/writer/status`
- `/api/writer/technical/masterpiece`
- `/api/writer/templates`

### `writing`  (12 endpointów)

- `/api/writing/auction`
- `/api/writing/auction/kb/fetch`
- `/api/writing/auction/kb/learn`
- `/api/writing/auction/pro`
- `/api/writing/auction/suggest-tags`
- `/api/writing/creative`
- `/api/writing/fashion/analyze`
- `/api/writing/masterpiece/article`
- `/api/writing/masterpiece/sales`
- `/api/writing/masterpiece/technical`
- `/api/writing/social`
- `/api/writing/vinted`


## Pełna lista

### `/api/admin/cache/clear`  (POST)
- **description:** 🗑️ Clear cache
- **group:** `admin`

### `/api/admin/cache/stats`  (GET)
- **description:** 📊 Get cache statistics
- **group:** `admin`

### `/api/admin/jwt/rotate`  (POST)
- **group:** `admin`

### `/api/admin/ratelimit/config`  (GET)
- **description:** ⚙️ Get rate limit configuration
- **group:** `admin`

### `/api/admin/ratelimit/usage/{user_id}`  (GET)
- **description:** 📈 Get rate limit usage for user
- **group:** `admin`

### `/api/automation/status`  (GET)
- **description:** Podsumowanie automatycznych narzędzi i fast path.
- **group:** `automation`

### `/api/autoroute/analyze`  (POST)
- **description:** 🎯 Analizuje input użytkownika i zwraca najlepszy endpoint

Usage z frontu:
```javascript
const result = await fetch('/api/autoroute/analyze', {
    method: 'POST',
    body: JSON.stringify({
        user_input: "sprawdź pogodę w Warszawie",
        context: { hour: 14, recent_categories: ["research"] }
    })
});
```
- **group:** `autoroute`

### `/api/autoroute/endpoints`  (GET)
- **description:** 📋 Zwraca mapę wszystkich dostępnych endpointów dla frontu

Przydatne do generowania UI, podpowiedzi, itp.
- **group:** `autoroute`

### `/api/autoroute/execute`  (POST)
- **description:** ⚡ Analizuje input I AUTOMATYCZNIE WYKONUJE odpowiedni endpoint

To jest główna funkcja dla frontu - one-click routing!
- **group:** `autoroute`

### `/api/autoroute/stats`  (GET)
- **description:** 📊 Statystyki routingu dla dashboardu admina
- **group:** `autoroute`

### `/api/batch/metrics`  (GET)
- **summary:** Pobiera metryki procesora wsadowego
- **description:** Pobiera metryki i statystyki procesora wsadowego

Returns:
    Metryki procesora wsadowego
- **group:** `batch`

### `/api/batch/process`  (POST)
- **summary:** Wykonuje wsadowe przetwarzanie zapytań LLM
- **description:** Wykonuje wsadowe przetwarzanie wielu zapytań LLM jednocześnie

Args:
    data: Zawiera:
        - messages_list: Lista list wiadomości (każda lista to wiadomości dla jednego wywołania LLM)
        - params_list: (opcjonalne) Lista parametrów dla każdego wywołania
        
Returns:
    Lista odpowiedzi LLM
- **group:** `batch`

### `/api/batch/shutdown`  (POST)
- **summary:** Zatrzymuje procesor wsadowy
- **description:** Zatrzymuje procesor wsadowy

Returns:
    Status operacji
- **group:** `batch`

### `/api/batch/submit`  (POST)
- **summary:** Dodaje pojedyncze zapytanie do wsadowego przetwarzania
- **description:** Dodaje pojedyncze zapytanie do wsadowego przetwarzania

Args:
    data: Zawiera:
        - messages: Lista wiadomości dla LLM
        - params: (opcjonalne) Parametry dla LLM
        - priority: (opcjonalne) Priorytet zapytania
        - request_id: (opcjonalne) Identyfikator zapytania
        
Returns:
    Odpowiedź LLM
- **group:** `batch`

### `/api/captcha/balance`  (GET)
- **description:** Sprawdź saldo 2captcha
- **group:** `captcha`

### `/api/captcha/solve`  (POST)
- **description:** Rozwiąż captcha przez 2captcha API
- **group:** `captcha`

### `/api/chat/assistant`  (POST)
- **group:** `chat`

### `/api/chat/assistant/stream`  (POST)
- **group:** `chat`

### `/api/chat/auto`  (POST)
- **group:** `chat`

### `/api/code/deps/install`  (POST)
- **description:** 📦 Install dependencies

Wymaga confirm=True!
- **group:** `code`

### `/api/code/docker/build`  (POST)
- **description:** 🐳 Build Docker image

Wymaga confirm=True!
- **group:** `code`

### `/api/code/docker/run`  (POST)
- **description:** 🚀 Run Docker container

Wymaga confirm=True!
- **group:** `code`

### `/api/code/exec`  (POST)
- **description:** 🔧 Execute shell command

Wymaga confirm=True dla bezpieczeństwa!
Użyj dry_run=True dla preview.
- **group:** `code`

### `/api/code/format`  (POST)
- **description:** 💅 Format code

Wymaga confirm=True jeśli check=False!
- **group:** `code`

### `/api/code/git`  (POST)
- **description:** 🔀 Git operations

Wymaga confirm=True dla destructive ops (commit, push)!
- **group:** `code`

### `/api/code/init`  (POST)
- **description:** 🆕 Initialize new project

Creates: src/, tests/, README.md, pyproject.toml/package.json
- **group:** `code`

### `/api/code/lint`  (POST)
- **description:** ✨ Lint code

Wymaga confirm=True jeśli fix=True!
- **group:** `code`

### `/api/code/plan`  (POST)
- **description:** 📋 Plan project steps

Zwraca rekomendowane kroki dla projektu
- **group:** `code`

### `/api/code/read`  (GET)
- **description:** 📖 Read file
- **group:** `code`

### `/api/code/snapshot`  (GET)
- **description:** 📊 System snapshot - dostępne narzędzia

Zwraca informacje o dostępnych narzędziach programistycznych
- **group:** `code`

### `/api/code/test`  (POST)
- **description:** 🧪 Run tests

Wymaga confirm=True!
- **group:** `code`

### `/api/code/tree`  (GET)
- **description:** 🌳 Read project tree
- **group:** `code`

### `/api/code/write`  (POST)
- **description:** 📝 Write file

Wymaga confirm=True!
- **group:** `code`

### `/api/cognitive/nlp/analyze`  (POST)
- **description:** 🔍 ZAAWANSOWANA ANALIZA NLP

Kompleksowa analiza tekstu z wykorzystaniem spaCy (pl_core_news_sm):
- NER (Named Entity Recognition): osoby, organizacje, lokalizacje, daty
- Keywords extraction: najważniejsze słowa kluczowe
- Sentiment analysis: pozytywny/negatywny/neutralny
- POS tagging: części mowy
- Dependency parsing: relacje syntaktyczne
- Phrase extraction: wydobycie fraz

**Zwraca:**
- entities: Lista encji z typami (PERSON, ORG, LOC, DATE, etc.)
- keywords: Słowa kluczowe z wagami
- sentiment: {score, label, confidence}
- pos_tags: Części mowy
- dependencies: Relacje syntaktyczne (jeśli włączone)
- phrases: Wydobyte frazy
- **group:** `cognitive`

### `/api/cognitive/proactive/suggestions`  (POST)
- **description:** 💡 PROAKTYWNE SUGESTIE

Generuje inteligentne sugestie na podstawie:
- Analizy kontekstu konwersacji
- Wzorców użytkownika
- Tematów i intencji
- Predykcji potrzeb

**Zwraca:**
- suggestions: Lista sugestii z confidence score
- context_analysis: Analiza kontekstu (tematy, intencje, sentiment)
- next_probable_questions: Przewidywane pytania
- **group:** `cognitive`

### `/api/cognitive/process`  (POST)
- **description:** 🧠 PEŁNE PRZETWARZANIE KOGNITYWNE

Orkiestracja wszystkich 5 systemów kognitywnych:
1. Self-Reflection - dynamiczna refleksja
2. Knowledge Compression - kompresja wiedzy
3. Multi-Agent Orchestrator - wieloagentowe myślenie (Analityk, Kreatywny, Pragmatyczny, Krytyczny, Syntetyczny)
4. Future Predictor - przewidywanie kontekstu
5. Inner Language - wewnętrzny język semantyczny

**Tryby:**
- BASIC: Podstawowe przetwarzanie
- ENHANCED: Z refleksją i kompresją
- ADVANCED: Wszystkie systemy
- PREDICTIVE: Z predykcją przyszłości
- MULTI_AGENT: Z orkiestracją agentów
- FULL_COGNITIVE: Wszystkie systemy aktywne

**Zwraca:**
- primary_response: Główna odpowiedź
- reflection_insights: Insights z refleksji
- agent_perspectives: Perspektywy agentów (jeśli multi-agent)
- future_predictions: Predykcje (jeśli predictive)
- compressed_knowledge: Skompresowana wiedza
- inner_thought: Wewnętrzna myśl AI
- confidence_score, originality_score: Metryki
- **group:** `cognitive`

### `/api/cognitive/psychology/analyze`  (POST)
- **description:** 🧠 ANALIZA EMOCJONALNA

Zaawansowana analiza psychologiczna wiadomości:
- Podstawowe emocje (Plutchik's wheel: joy, trust, fear, surprise, sadness, disgust, anger, anticipation)
- PAD model: valence (pozytywna-negatywna), arousal (pobudzenie), dominance
- Sentiment analysis
- Mood tracking

**Zwraca:**
- emotions: Słownik emocji z intensywnością (0.0-1.0)
- valence, arousal, dominance: PAD scores
- mood: Długoterminowy nastrój
- sentiment: Sentiment analysis
- **group:** `cognitive`

### `/api/cognitive/psychology/state/{user_id}`  (GET)
- **description:** 📊 STAN PSYCHOLOGICZNY AI

Pobiera aktualny stan emocjonalny AI dla danego użytkownika
- **group:** `cognitive`

### `/api/cognitive/reflect`  (POST)
- **description:** 🔄 DYNAMICZNA REKURENCJA UMYSŁOWA

AI ocenia swoją odpowiedź i poprawia ją przez wielopoziomową refleksję:
- SURFACE: Podstawowa ewaluacja (faktyczność, jasność)
- MEDIUM: Logika, kompletność, kontekst, błędy
- DEEP: Kognitywna + pragmatyczna + meta + epistemologiczna analiza
- PROFOUND: Filozoficzna refleksja (ontologia, aksjologia, hermeneutyka)
- TRANSCENDENT: Przekroczenie granic myśli, transformacja

**Zwraca:**
- improved_response: Poprawiona odpowiedź
- meta_commentary: Meta-komentarz o procesie myślenia
- reflection_score: Jakość refleksji (0.0-1.0)
- insights_gained: Lista nauk z procesu
- corrections_made: Lista konkretnych poprawek
- **group:** `cognitive`

### `/api/cognitive/reflection/summary`  (GET)
- **description:** 📊 PODSUMOWANIE REFLEKSJI

Zwraca statystyki wszystkich procesów refleksji:
- Total reflections, average score, cycle time
- Depth distribution
- Total insights & corrections
- Meta-patterns
- **group:** `cognitive`

### `/api/cognitive/semantic/analyze`  (POST)
- **description:** 🧬 ANALIZA SEMANTYCZNA

Zaawansowana analiza semantyczna tekstu:
- Embeddingi (sentence-transformers)
- Ekstrakcja konceptów
- Identyfikacja relacji
- Podobieństwo semantyczne (jeśli compare_with)

**Zwraca:**
- embedding: Wektor semantyczny (768 wymiarów)
- concepts: Wydobyte koncepty
- relations: Relacje między konceptami
- similarity: Podobieństwo (jeśli compare_with)
- **group:** `cognitive`

### `/api/cognitive/status`  (GET)
- **description:** 📊 STATUS SYSTEMÓW KOGNITYWNYCH

Zwraca status wszystkich zaawansowanych systemów
- **group:** `cognitive`

### `/api/cognitive/tools/list`  (GET)
- **description:** 🛠️ LISTA NARZĘDZI KOGNITYWNYCH

Zwraca listę wszystkich dostępnych narzędzi z tools_registry
- **group:** `cognitive`

### `/api/endpoints/list`  (GET)
- **description:** Lista wszystkich endpointów API
- **group:** `endpoints`

### `/api/fashion/categories`  (GET)
- **summary:** Pobiera dostępne kategorie mody
- **description:** Pobiera listę dostępnych kategorii mody.

Returns:
    Lista kategorii modowych
- **group:** `fashion`

### `/api/fashion/detect-brand`  (POST)
- **summary:** Rozpoznaje markę z obrazu
- **description:** Rozpoznaje markę modową z przesłanego obrazu.

Args:
    request: Zawiera description (opcjonalne), user_id
    image: Przesłany obraz do analizy
    
Returns:
    Rozpoznaną markę z prawdopodobieństwem
- **group:** `fashion`

### `/api/fashion/forecast-trends`  (POST)
- **summary:** Prognozuje trendy modowe
- **description:** Prognozuje trendy modowe dla danej kategorii i okresu.

Args:
    request: Zawiera category, timeframe, region, user_id
    
Returns:
    Prognozy trendów z poziomem pewności
- **group:** `fashion`

### `/api/fashion/generate-outfit`  (POST)
- **summary:** Generuje stylizację na podstawie okazji i pogody
- **description:** Generuje stylizację na podstawie okazji, pogody i preferencji stylu.

Args:
    request: Zawiera occasion, weather, style_preferences, user_id
    
Returns:
    Pełną stylizację z rekomendacjami
- **group:** `fashion`

### `/api/fashion/occasions`  (GET)
- **summary:** Pobiera dostępne okazje
- **description:** Pobiera listę dostępnych okazji do stylizacji.

Returns:
    Lista okazji
- **group:** `fashion`

### `/api/fashion/stats`  (GET)
- **summary:** Pobiera statystyki AI Fashion
- **description:** Pobiera statystyki użycia AI Fashion Manager.

Returns:
    Statystyki systemu mody
- **group:** `fashion`

### `/api/fashion/weather-types`  (GET)
- **summary:** Pobiera typy pogody
- **description:** Pobiera listę typów pogody do stylizacji.

Returns:
    Lista typów pogody
- **group:** `fashion`

### `/api/ff/proxy`  (POST)
- **group:** `ff`

### `/api/files/analyze`  (POST)
- **description:** 🔍 Analyze uploaded file

Extract text, metadata, dimensions, etc.
- **group:** `files`

### `/api/files/batch/analyze`  (POST)
- **description:** 🔍 Batch analyze multiple files
- **group:** `files`

### `/api/files/delete`  (POST)
- **description:** 🗑️ Delete file
- **group:** `files`

### `/api/files/download`  (GET)
- **description:** 📥 Download file by ID
- **group:** `files`

### `/api/files/list`  (GET)
- **description:** 📋 List all uploaded files
- **group:** `files`

### `/api/files/stats`  (GET)
- **description:** 📊 Files statistics
- **group:** `files`

### `/api/files/thumb/{tenant}/{day}/{name}`  (GET)
- **group:** `files`

### `/api/files/upload`  (POST)
- **group:** `files`

### `/api/files/upload`  (POST)
- **description:** 📤 Upload file (multipart/form-data)

Supports: PDF, images, ZIP, text files, video, audio, code files
Max size: 50MB
- **group:** `files`

### `/api/files/upload/base64`  (POST)
- **description:** 📤 Upload file (base64 encoded)

For frontend that sends files as base64
- **group:** `files`

### `/api/files/{tenant}/{day}/{name}`  (GET)
- **group:** `files`

### `/api/hacker/exploit/sqli`  (POST)
- **description:** 💉 SQL Injection Tester - test parametrów na SQLi
- **group:** `hacker`

### `/api/hacker/exploits/list`  (GET)
- **description:** 🎯 Lista dostępnych modułów exploitów
- **group:** `hacker`

### `/api/hacker/recon/domain`  (POST)
- **description:** 🕵️ Domain Reconnaissance - zbieraj intel o domenie
- **group:** `hacker`

### `/api/hacker/scan/ports`  (POST)
- **description:** 🔍 Port Scanner - skanuj porty na targecie
- **group:** `hacker`

### `/api/hacker/scan/vulnerabilities`  (POST)
- **description:** 🔐 Vulnerability Scanner - szukaj podatności
- **group:** `hacker`

### `/api/hacker/tools/status`  (GET)
- **description:** 🛠️ Status narzędzi hackingowych
- **group:** `hacker`

### `/api/image/file/{tenant}/{name}`  (GET)
- **group:** `image`

### `/api/image/generate`  (POST)
- **group:** `image`

### `/api/internal/ui`  (GET)
- **description:** Return manifest and optionally token for UI. Token is returned only if env UI_EXPOSE_TOKEN=1 or request is local.
- **group:** `internal`

### `/api/internal/ui_token`  (GET)
- **description:** Return the AUTH_TOKEN only if UI_EXPOSE_TOKEN=1 or request is local.
- **group:** `internal`

### `/api/lang/detect`  (POST)
- **group:** `lang`

### `/api/memory/add`  (POST)
- **group:** `memory`

### `/api/memory/export`  (GET)
- **group:** `memory`

### `/api/memory/import`  (POST)
- **group:** `memory`

### `/api/memory/optimize`  (POST)
- **group:** `memory`

### `/api/memory/search`  (POST)
- **group:** `memory`

### `/api/memory/status`  (GET)
- **description:** Status systemu pamięci
- **group:** `memory`

### `/api/ml/model-info`  (GET)
- **summary:** Informacje o modelu ML
- **description:** Pobiera informacje o aktualnym modelu ML.

Returns:
    Model architecture, features, performance
- **group:** `ml`

### `/api/ml/predict-suggestions`  (POST)
- **summary:** Przewiduje sugestie ML (95% accuracy)
- **description:** Przewiduje proaktywne sugestie używając Machine Learning.
Trafność: 80% → 95% dzięki sklearn/pytorch.

Args:
    request: user_id, message, conversation_history, max_suggestions
    
Returns:
    ML-predicted suggestions z wysoką trafnością
- **group:** `ml`

### `/api/ml/record-feedback`  (POST)
- **summary:** Zapisuje feedback dla ML model
- **description:** Zapisuje feedback użytkownika dla poprawy modelu ML.
Dane uczące dla sklearn/pytorch.

Args:
    request: feedback data z user interaction
    
Returns:
    Potwierdzenie zapisania feedback
- **group:** `ml`

### `/api/ml/retrain`  (POST)
- **summary:** Retrenuje model ML
- **description:** Inicjuje retrening modelu ML na nowych danych.

Returns:
    Status retrainingu
- **group:** `ml`

### `/api/ml/stats`  (GET)
- **summary:** Pobiera statystyki ML model
- **description:** Pobiera statystyki modelu Machine Learning.

Returns:
    Accuracy, training data size, model metrics
- **group:** `ml`

### `/api/nlp/analyze`  (POST)
- **description:** Przeprowadza kompleksową analizę NLP pojedynczego tekstu

- **text**: Tekst do analizy (1-10000 znaków)
- **use_cache**: Czy używać cache'a (domyślnie True)
- **group:** `nlp`

### `/api/nlp/batch-analyze`  (POST)
- **description:** Przeprowadza analizę NLP dla wielu tekstów wsadowo

- **texts**: Lista tekstów (1-50 tekstów)
- **batch_size**: Rozmiar wsadu (1-20)
- **group:** `nlp`

### `/api/nlp/entities`  (POST)
- **description:** Ekstrahuje encje nazwane z tekstu

- **text**: Tekst do analizy
- **use_cache**: Czy używać cache'a
- **group:** `nlp`

### `/api/nlp/extract-topics`  (POST)
- **description:** Ekstrahuje tematy z kolekcji tekstów

- **texts**: Lista tekstów (1-100 tekstów)
- **num_topics**: Liczba tematów do ekstrakcji (1-20)
- **group:** `nlp`

### `/api/nlp/key-phrases`  (POST)
- **description:** Ekstrahuje frazy kluczowe z tekstu

- **text**: Tekst do analizy
- **use_cache**: Czy używać cache'a
- **group:** `nlp`

### `/api/nlp/readability`  (POST)
- **description:** Oblicza ocenę czytelności tekstu

- **text**: Tekst do analizy
- **use_cache**: Czy używać cache'a
- **group:** `nlp`

### `/api/nlp/sentiment`  (POST)
- **description:** Analizuje sentyment tekstu

- **text**: Tekst do analizy
- **use_cache**: Czy używać cache'a
- **group:** `nlp`

### `/api/nlp/stats`  (GET)
- **description:** Zwraca statystyki procesora NLP

- Statystyki użycia, wydajności i modeli językowych
- **group:** `nlp`

### `/api/prometheus/health`  (GET)
- **description:** Health check dla Prometheus
- **group:** `prometheus`

### `/api/prometheus/metrics`  (GET)
- **description:** Endpoint dla Prometheus - metryki w formacie tekstowym
- **group:** `prometheus`

### `/api/prometheus/stats`  (GET)
- **description:** Statystyki w formacie JSON
- **group:** `prometheus`

### `/api/psyche`  (POST)
- **summary:** Analiza wiadomości i aktualizacja stanu
- **group:** `psyche`

### `/api/psyche/history`  (GET)
- **summary:** Ostatnie wiadomości
- **group:** `psyche`

### `/api/psyche/reset`  (POST)
- **summary:** Reset stanu
- **group:** `psyche`

### `/api/psyche/state`  (GET)
- **summary:** Pobierz bieżący stan
- **group:** `psyche`

### `/api/psyche/state`  (POST)
- **summary:** Ustaw stan
- **group:** `psyche`

### `/api/research/autonauka`  (POST)
- **description:** 🧠 AUTO-NAUKA Z WEB RESEARCH

Pełna pipeline:
1. Wyszukiwanie w wielu źródłach (DDG, Wiki, SERPAPI, arXiv, S2)
2. Scraping treści (Firecrawl lub fallback)
3. Analiza semantyczna i embedding
4. Generowanie odpowiedzi przez LLM
5. Opcjonalnie: zapis do LTM

**Przykład:**
```json
{
  "query": "Wyjaśnij teorię strun",
  "topk": 8,
  "user_id": "user123",
  "save_to_ltm": true
}
```
- **group:** `research`

### `/api/research/search`  (POST)
- **description:** 🌐 OGÓLNE WYSZUKIWANIE W INTERNECIE

Przeszukuje wiele źródeł:
- DuckDuckGo (zawsze)
- Wikipedia (zawsze)
- SERPAPI/Google (jeśli klucz API)
- arXiv (tryb full/grounded)
- Semantic Scholar (tryb full/grounded)

**Przykład:**
```json
{
  "query": "czym jest kwantowa superpozycja",
  "topk": 5,
  "mode": "full"
}
```
- **group:** `research`

### `/api/research/sources`  (GET)
- **description:** 📚 LISTA DOSTĘPNYCH ŹRÓDEŁ

Zwraca informacje o dostępnych źródłach danych i ich statusie.
- **group:** `research`

### `/api/research/test`  (GET)
- **description:** 🧪 TEST WEB SEARCH

Testuje czy research działa poprawnie.
- **group:** `research`

### `/api/search/compare`  (POST)
- **description:** 🔬 PORÓWNANIE METOD WYSZUKIWANIA

Wykonuje wyszukiwanie wszystkimi 3 metodami oddzielnie
i pokazuje różnice w wynikach.
- **group:** `search`

### `/api/search/hybrid`  (POST)
- **description:** 🔥 ZAAWANSOWANE WYSZUKIWANIE HYBRYDOWE 🔥

Łączy 3 metody:
- FTS5 Full-Text Search (40%)
- Semantic Vector Search (35%)
- Fuzzy String Matching (25%)

Zwraca najlepsze wyniki z breakdown score'ów i timestamp.
- **group:** `search`

### `/api/search/stats`  (GET)
- **description:** Statystyki pamięci użytkownika
- **group:** `search`

### `/api/search/test`  (GET)
- **description:** Quick test endpoint - GET request dla łatwego testowania

Example: /api/search/test?q=python&limit=10
- **group:** `search`

### `/api/search/widget`  (GET)
- **description:** 🎨 FRONTEND WIDGET - Interaktywny interfejs do testowania hybrid search
- **group:** `search`

### `/api/stt/file/{tenant}/{name}`  (GET)
- **group:** `stt`

### `/api/stt/providers`  (GET)
- **description:** Lista dostępnych providerów STT
- **group:** `stt`

### `/api/stt/transcribe`  (POST)
- **group:** `stt`

### `/api/stt/transcribe`  (POST)
- **description:** Zamień audio na tekst (Speech-to-Text)

Wspierane formaty: mp3, wav, m4a, webm, ogg
Max size: 25MB
- **group:** `stt`

### `/api/suggestions/analyze`  (POST)
- **summary:** Analizuje wiadomość bez generowania sugestii
- **description:** Analizuje wiadomość bez generowania sugestii.

Args:
    data: Zawiera:
        - user_id: ID użytkownika
        - message: Wiadomość użytkownika
        
Returns:
    Wyniki analizy
- **group:** `suggestions`

### `/api/suggestions/generate`  (POST)
- **summary:** Generuje proaktywne sugestie dla wiadomości
- **description:** Generuje proaktywne sugestie dla wiadomości użytkownika.

Args:
    data: Zawiera:
        - user_id: ID użytkownika
        - message: Wiadomość użytkownika
        - conversation_history: (opcjonalne) Historia konwersacji
        - last_ai_response: (opcjonalne) Ostatnia odpowiedź AI
        - force: (opcjonalne) Wymuś sugestię
        
Returns:
    Lista sugestii
- **group:** `suggestions`

### `/api/suggestions/inject`  (POST)
- **summary:** Dodaje sugestie do promptu
- **description:** Dodaje sugestie do promptu systemowego.

Args:
    data: Zawiera:
        - base_prompt: Bazowy prompt systemowy
        - suggestions: Lista sugestii
        
Returns:
    Prompt z dodanymi sugestiami
- **group:** `suggestions`

### `/api/suggestions/stats`  (GET)
- **summary:** Pobiera statystyki sugestii
- **description:** Pobiera statystyki generowania sugestii.

Returns:
    Statystyki sugestii
- **group:** `suggestions`

### `/api/travel/attractions/{city}`  (GET)
- **description:** 🏛️ Szybki dostęp do atrakcji
- **group:** `travel`

### `/api/travel/geocode`  (GET)
- **description:** 📍 Pobierz współrzędne geograficzne miasta

Używa OpenTripMap API do geocodingu

Przykład:
```
GET /api/travel/geocode?city=Gdańsk
```

Zwraca:
```json
{
    "ok": true,
    "city": "Gdańsk",
    "coordinates": {
        "lat": 54.352,
        "lon": 18.646
    }
}
```
- **group:** `travel`

### `/api/travel/hotels/{city}`  (GET)
- **description:** 🏨 Szybki dostęp do hoteli
- **group:** `travel`

### `/api/travel/restaurants/{city}`  (GET)
- **description:** 🍽️ Szybki dostęp do restauracji
- **group:** `travel`

### `/api/travel/search`  (GET)
- **description:** 🗺️ Wyszukaj miejsca w mieście

Parametry:
- city: nazwa miasta (np. "Warszawa", "Kraków")
- what: co szukamy
  - "attractions" - atrakcje turystyczne
  - "hotels" - hotele
  - "restaurants" - restauracje i kawiarnie

Źródła:
- OpenTripMap API (geocoding)
- SERPAPI Google Maps (hotele, atrakcje)
- Overpass API / OpenStreetMap (restauracje)

Przykład:
```
GET /api/travel/search?city=Kraków&what=restaurants
```
- **group:** `travel`

### `/api/travel/trip-plan`  (GET)
- **description:** 🗓️ Zaplanuj wycieczkę (AI-powered)

Generuje plan wycieczki bazując na:
- Długość pobytu (dni)
- Zainteresowania
- Dostępne atrakcje

Przykład:
```
GET /api/travel/trip-plan?city=Kraków&days=2&interests=culture,food
```
- **group:** `travel`

### `/api/tts/speak`  (POST)
- **description:** Generuje audio z tekstu

Body:
    {
        "text": "Tekst do wypowiedzenia",
        "voice": "rachel"  // opcjonalnie: rachel, antoni, adam, bella
    }

Returns:
    audio/mpeg (MP3)
- **group:** `tts`

### `/api/tts/voices`  (GET)
- **description:** Lista dostępnych głosów
- **group:** `tts`

### `/api/vision/describe`  (POST)
- **group:** `vision`

### `/api/vision/ocr`  (POST)
- **group:** `vision`

### `/api/voice/file/{tenant}/{name}`  (GET)
- **group:** `voice`

### `/api/voice/tts`  (POST)
- **group:** `voice`

### `/api/writer/article/masterpiece`  (POST)
- **description:** Generuj mistrzowski artykuł

Args:
    request: Parametry artykułu

Returns:
    Kompletny artykuł
- **group:** `writer`

### `/api/writer/auction/knowledge`  (GET)
- **description:** Pobierz wiedzę aukcyjną z bazy

Returns:
    Wiedza aukcyjna pogrupowana tematycznie
- **group:** `writer`

### `/api/writer/auction/learn`  (POST)
- **description:** Naucz system wiedzy aukcyjnej

Args:
    request: Elementy wiedzy aukcyjnej do nauczenia

Returns:
    Status nauki
- **group:** `writer`

### `/api/writer/auction/pro`  (POST)
- **description:** Zaawansowane generowanie opisu aukcji

Args:
    request: Parametry zaawansowanego opisu aukcji

Returns:
    Profesjonalny opis aukcji
- **group:** `writer`

### `/api/writer/auction/tags`  (GET)
- **description:** Sugeruj tagi dla aukcji

Args:
    title: Tytuł aukcji
    description: Opis aukcji

Returns:
    Sugerowane tagi
- **group:** `writer`

### `/api/writer/creative`  (POST)
- **description:** Generuj kreatywny tekst na zadany temat

Args:
    request: Parametry tekstu kreatywnego

Returns:
    Wygenerowany tekst kreatywny
- **group:** `writer`

### `/api/writer/fashion/analyze`  (POST)
- **description:** Analizuj tekst pod kątem mody i stylu

Args:
    text: Tekst do analizy

Returns:
    Analiza modowa tekstu
- **group:** `writer`

### `/api/writer/product`  (POST)
- **description:** Generuj opis produktu dla różnych platform

Args:
    request: Parametry opisu produktu

Returns:
    Opis produktu
- **group:** `writer`

### `/api/writer/sales/masterpiece`  (POST)
- **description:** Generuj mistrzowski tekst sprzedażowy

Args:
    request: Parametry tekstu sprzedażowego

Returns:
    Profesjonalny tekst sprzedażowy
- **group:** `writer`

### `/api/writer/social`  (POST)
- **description:** Generuj posty na media społecznościowe

Args:
    request: Parametry posta społecznościowego

Returns:
    Lista wariantów postów
- **group:** `writer`

### `/api/writer/status`  (GET)
- **description:** Status modułu Writer Pro

Returns:
    Informacje o dostępności funkcji pisarskich
- **group:** `writer`

### `/api/writer/technical/masterpiece`  (POST)
- **description:** Generuj mistrzowską dokumentację techniczną

Args:
    request: Parametry dokumentacji technicznej

Returns:
    Kompletna dokumentacja techniczna
- **group:** `writer`

### `/api/writer/templates`  (GET)
- **description:** Pobierz dostępne szablony pisarskie

Returns:
    Lista dostępnych szablonów i ich parametrów
- **group:** `writer`

### `/api/writing/auction`  (POST)
- **description:** Generator opisów aukcyjnych.
- **group:** `writing`

### `/api/writing/auction/kb/fetch`  (GET)
- **description:** Pobierz bazę wiedzy aukcyjnej.
- **group:** `writing`

### `/api/writing/auction/kb/learn`  (POST)
- **description:** Naucz bazę wiedzy aukcyjnej nowych elementów.
- **group:** `writing`

### `/api/writing/auction/pro`  (POST)
- **description:** Generator profesjonalnych opisów aukcyjnych z wersją A/B.
- **group:** `writing`

### `/api/writing/auction/suggest-tags`  (POST)
- **description:** Sugeruj tagi dla aukcji.
- **group:** `writing`

### `/api/writing/creative`  (POST)
- **description:** Kreatywne pisanie artykułów, esejów i tekstów.
- **group:** `writing`

### `/api/writing/fashion/analyze`  (POST)
- **description:** Analiza tekstu pod kątem elementów mody.
- **group:** `writing`

### `/api/writing/masterpiece/article`  (POST)
- **description:** Generator mistrzowskich artykułów.
- **group:** `writing`

### `/api/writing/masterpiece/sales`  (POST)
- **description:** Generator mistrzowskich tekstów sprzedażowych.
- **group:** `writing`

### `/api/writing/masterpiece/technical`  (POST)
- **description:** Generator mistrzowskich wyjaśnień technicznych.
- **group:** `writing`

### `/api/writing/social`  (POST)
- **description:** Generator postów do mediów społecznościowych.
- **group:** `writing`

### `/api/writing/vinted`  (POST)
- **description:** Generator opisów dla Vinted.
- **group:** `writing`
