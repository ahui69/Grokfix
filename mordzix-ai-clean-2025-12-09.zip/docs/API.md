# 📚 MORDZIX AI - API Documentation

> Kompletna dokumentacja wszystkich endpointów API

---

## 🔐 Autoryzacja

Wszystkie endpointy wymagają tokenu autoryzacji.

### Header
```
Authorization: Bearer YOUR_TOKEN
```

### Query Parameter
```
?token=YOUR_TOKEN
```

---

## 💬 Chat API

### POST /api/chat
Główny endpoint konwersacyjny.

**Request:**
```json
{
  "message": "Twoja wiadomość",
  "session_id": "optional-session-id",
  "stream": true,
  "web_search": "auto",
  "context": []
}
```

**Response (stream=false):**
```json
{
  "ok": true,
  "response": "Odpowiedź AI",
  "session_id": "abc123",
  "web_search_used": false,
  "sources": []
}
```

### GET /api/chat/modes
Lista dostępnych trybów konwersacji.

**Response:**
```json
{
  "modes": ["creative", "analytical", "technical", "casual"]
}
```

---

## ⚖️ Legal Office API

### POST /api/legal/analyze
Analiza pisma urzędowego.

**Request (form-data):**
```
content: Treść pisma (tekst lub base64 obrazu)
is_image: false
additional_info: Dodatkowe informacje
```

**Response:**
```json
{
  "ok": true,
  "analysis": {
    "institution": {
      "type": "urzad_skarbowy",
      "name": "Urząd Skarbowy"
    },
    "document": {
      "type": "decyzja",
      "key_info": {
        "sygnatura": "123/2024",
        "kwota": "5000.00",
        "termin": "14"
      }
    },
    "legal": {
      "applicable_laws": ["Ordynacja podatkowa", "..."],
      "deadlines": {"odwolanie": 14},
      "deadline_days": 14
    },
    "suggested_responses": ["odwolanie", "wniosek"]
  }
}
```

### POST /api/legal/generate-response
Generowanie odpowiedzi na pismo.

**Request:**
```json
{
  "document_analysis": {...},
  "response_type": "odwolanie",
  "user_arguments": "Moje argumenty...",
  "user_data": {
    "name": "Jan Kowalski",
    "address": "ul. Przykładowa 1"
  },
  "deadline_extension": false
}
```

**Response:**
```json
{
  "ok": true,
  "response": {
    "type": "odwolanie",
    "content": "Pełna treść pisma...",
    "generated_at": "05.12.2024",
    "legal_basis": ["art. 220 Ordynacji podatkowej"],
    "tips": ["Wyślij listem poleconym", "..."]
  }
}
```

### POST /api/legal/upload-scan
Upload skanu z automatycznym OCR.

**Request (multipart/form-data):**
```
file: [plik obrazu lub PDF]
```

**Response:**
```json
{
  "ok": true,
  "filename": "scan.jpg",
  "extracted_text": "Treść z OCR...",
  "analysis": {
    "institution": "urzad_skarbowy",
    "document_type": "decyzja",
    "key_info": {...}
  }
}
```

### POST /api/legal/calculate-deadline
Kalkulator terminów.

**Request (form-data):**
```
document_date: 2024-12-01
institution: urzad_skarbowy
response_type: odwolanie
```

**Response:**
```json
{
  "ok": true,
  "deadline": {
    "document_date": "01.12.2024",
    "deadline_date": "15.12.2024",
    "days_allowed": 14,
    "days_left": 10,
    "is_urgent": false,
    "is_expired": false
  }
}
```

### GET /api/legal/templates
Lista szablonów pism.

### GET /api/legal/institutions
Lista obsługiwanych instytucji.

---

## 🎤 Media API

### POST /api/tts/generate
Generowanie mowy z tekstu.

**Request:**
```json
{
  "text": "Tekst do przeczytania",
  "voice": "adam",
  "provider": "elevenlabs"
}
```

**Response:**
```json
{
  "ok": true,
  "audio_url": "/api/media/audio/abc123.mp3",
  "duration": 5.2
}
```

### GET /api/tts/voices
Lista dostępnych głosów.

### POST /api/media/generate-image
Generowanie obrazu.

**Request:**
```json
{
  "prompt": "Opis obrazu",
  "style": "photorealistic",
  "size": "1024x1024"
}
```

**Response:**
```json
{
  "ok": true,
  "url": "/api/media/images/abc123.png",
  "revised_prompt": "..."
}
```

---

## 🧠 Memory API

### GET /api/memory/status
Status systemu pamięci.

**Response:**
```json
{
  "ok": true,
  "stm_count": 50,
  "ltm_count": 1234,
  "associations": 567
}
```

### POST /api/memory/store
Zapisz wspomnienie.

**Request:**
```json
{
  "content": "Treść wspomnienia",
  "category": "fact",
  "importance": 0.8
}
```

### POST /api/memory/search
Wyszukaj wspomnienia.

**Request:**
```json
{
  "query": "Szukana fraza",
  "limit": 10
}
```

---

## 💻 Code API

### POST /api/code/execute
Wykonaj kod Python.

**Request:**
```json
{
  "code": "print('Hello World')",
  "timeout": 30
}
```

**Response:**
```json
{
  "ok": true,
  "output": "Hello World\n",
  "error": null,
  "execution_time": 0.05
}
```

### POST /api/code/analyze
Analiza kodu.

### POST /api/code/lint
Linting kodu.

### GET /api/code/tree
Drzewo katalogów projektu.

---

## 🔍 Search API

### POST /api/research/search
Wyszukiwanie w internecie.

**Request:**
```json
{
  "query": "Szukana fraza",
  "sources": ["tavily", "brave"],
  "max_results": 10
}
```

**Response:**
```json
{
  "ok": true,
  "results": [
    {
      "title": "Tytuł",
      "url": "https://...",
      "snippet": "Fragment...",
      "source": "tavily"
    }
  ],
  "query_time": 0.89
}
```

### GET /api/research/sources
Lista dostępnych źródeł.

---

## 📊 Admin API

### GET /api/admin/stats
Statystyki systemu.

**Response:**
```json
{
  "ok": true,
  "stats": {
    "total_requests": 12345,
    "active_sessions": 42,
    "memory_usage": "256MB",
    "uptime": "24h 30m"
  }
}
```

### POST /api/admin/cache/clear
Wyczyść cache.

### GET /api/endpoints/list
Lista wszystkich endpointów.

---

## 🏥 Health API

### GET /health
Status zdrowia systemu.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": 1701765432.123,
  "checks": {
    "api": "ok",
    "database": "ok",
    "memory": "ok"
  }
}
```

---

## 📈 Metrics API

### GET /metrics
Metryki Prometheus.

---

## ⚠️ Kody błędów

| Kod | Znaczenie |
|-----|-----------|
| 200 | OK |
| 400 | Bad Request - nieprawidłowe dane |
| 401 | Unauthorized - brak tokenu |
| 403 | Forbidden - brak uprawnień |
| 404 | Not Found - nie znaleziono |
| 429 | Too Many Requests - rate limit |
| 500 | Internal Server Error |

---

## 📝 Rate Limiting

- **Limit:** 60 requestów/minutę
- **Header:** `X-RateLimit-Remaining`

---

## 🔗 Pełna lista endpointów

Dostępna pod: `GET /api/endpoints/list`

Lub w Swagger UI: `http://localhost:8080/docs`
