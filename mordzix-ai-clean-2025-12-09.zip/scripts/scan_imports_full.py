#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Pełny skan importów projektu Mordzix-AI.

• Przechodzi po całym katalogu projektu.
• Dla każdego pliku .py (poza venv, .git, __pycache__, itp.) buduje nazwę modułu.
• Próbuje wykonać import importlib.import_module(mod_name).
• Zlicza poprawne i błędne importy.

Uruchamiaj ZAWSZE z root projektu:
    cd /root/mordzix-ai
    source .venv/bin/activate
    ./scripts/scan_imports_full.py
"""

import os
import sys
import importlib
from pathlib import Path
from typing import List, Tuple

BASE_DIR = Path(__file__).resolve().parent.parent


IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".idea",
    ".vscode",
    ".ansible",
    "tmp",
    "logs",
    "dist",
    "build",
}

IGNORED_FILES = {
    "__init__.py",
}


def build_module_name(py_path: Path) -> str:
    """
    Zamień ścieżkę do pliku .py na nazwę modułu Pythona,
    np. /root/mordzix-ai/core/memory.py -> core.memory
         /root/mordzix-ai/admin_endpoint.py -> admin_endpoint
    """
    rel = py_path.relative_to(BASE_DIR)
    rel_no_ext = rel.with_suffix("")
    parts = list(rel_no_ext.parts)

    # jeśli jest np. scripts/scan_imports_full.py – też liczymy jako moduł scripts.scan_imports_full
    return ".".join(parts)


def iter_python_modules() -> List[Tuple[str, Path]]:
    modules: List[Tuple[str, Path]] = []

    for root, dirs, files in os.walk(BASE_DIR):
        # odfiltruj katalogi-śmieci
        dirs[:] = [
            d
            for d in dirs
            if d not in IGNORED_DIRS and not d.startswith(".")
        ]

        for fname in files:
            if not fname.endswith(".py"):
                continue
            if fname in IGNORED_FILES:
                continue

            full_path = Path(root) / fname
            mod_name = build_module_name(full_path)
            modules.append((mod_name, full_path))

    # posortuj alfabetycznie po nazwie modułu
    modules.sort(key=lambda x: x[0])
    return modules


def print_header() -> None:
    print("=" * 72)
    print("🔍  PEŁNY SKAN IMPORTÓW – MORDZIX-AI")
    print("=" * 72)
    print(f"ROOT: {BASE_DIR}")
    print()


def main() -> None:
    # dopnij root projektu do sys.path, żeby importy działały jak przy uruchomieniu app.py
    root_str = str(BASE_DIR)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)

    print_header()

    modules = iter_python_modules()
    total = len(modules)
    ok = 0
    failed = 0

    for idx, (mod_name, path) in enumerate(modules, start=1):
        print(f"({idx:03d}/{total:03d}) 🔎 Testuję import: {mod_name}")
        print(f"    📁 {path}")
        try:
            importlib.import_module(mod_name)
            print("    ✅ OK\n")
            ok += 1
        except Exception as e:
            print(f"    ❌ ERROR: {e!r}\n")
            failed += 1

    print("=" * 72)
    print("📊  PODSUMOWANIE")
    print("=" * 72)
    print(f"✅ Poprawne importy : {ok}")
    print(f"❌ Błędne importy   : {failed}")
    print(f"📦 Razem modułów    : {total}")
    print("=" * 72)
    print()
    print("Tip: żeby zobaczyć tylko błędy, przewiń do pierwszego ❌ i czytaj w dół.")
    print("    Naprawiamy je po kolei, aż liczba błędów spadnie do 0.")
    print()


if __name__ == "__main__":
    main()
