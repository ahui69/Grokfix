#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Generator manifestu endpointów dla MORDZIX AI.

- ładuje app z rootowego app.py
- zbiera wszystkie trasy /api/*
- generuje:
    * endpoints_manifest.json
    * ENDPOINTS_MANIFEST.md
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI

# ======================================================================
#  Ustawienia ścieżek
# ======================================================================

SCRIPT_PATH = Path(__file__).resolve()
ROOT = SCRIPT_PATH.parent.parent  # /root/mordzix-ai

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# importujemy app z rootowego pliku app.py
from app import app  # noqa: E402  type: ignore


# ======================================================================
#  Pomocnicze funkcje
# ======================================================================

def _is_api_route(route) -> bool:
    """Czy dana trasa jest /api/* ?"""
    path = getattr(route, "path", "")
    if not isinstance(path, str):
        return False
    return path.startswith("/api/")


def _clean_methods(route) -> List[str]:
    methods = getattr(route, "methods", None) or set()
    return sorted(m for m in methods if m not in {"HEAD", "OPTIONS"})


def _group_name(path: str) -> str:
    """
    Grupujemy po segmencie zaraz po /api/
    /api/chat/assistant      -> chat
    /api/memory/status       -> memory
    /api/admin/cache/clear   -> admin
    """
    parts = path.split("/")
    if len(parts) >= 3 and parts[2]:
        return parts[2]
    return "root"


def _route_entry(route) -> Dict[str, Any]:
    path = getattr(route, "path", "")
    methods = _clean_methods(route)
    name = getattr(route, "name", "") or ""
    endpoint = getattr(route, "endpoint", None)

    module_name = ""
    qualname = ""
    if endpoint is not None:
        module_name = getattr(endpoint, "__module__", "") or ""
        qualname = getattr(endpoint, "__qualname__", "") or ""

    tags = getattr(route, "tags", None) or []

    return {
        "path": path,
        "methods": methods,
        "name": name,
        "tags": tags,
        "module": module_name,
        "endpoint": qualname,
    }


def collect_manifest(app: FastAPI) -> Dict[str, Any]:
    """Buduje strukturę manifestu z app.routes."""
    all_routes = [r for r in app.routes if hasattr(r, "path")]
    api_routes = [r for r in all_routes if _is_api_route(r)]

    groups: Dict[str, Dict[str, Any]] = {}

    for r in api_routes:
        entry = _route_entry(r)
        group = _group_name(entry["path"])

        if group not in groups:
            groups[group] = {
                "name": group,
                "count": 0,
                "routes": [],
            }

        groups[group]["routes"].append(entry)
        groups[group]["count"] += 1

    manifest: Dict[str, Any] = {
        "root": str(ROOT),
        "total": len(api_routes),
        "groups": groups,
        "routes": sorted(
            [_route_entry(r) for r in api_routes],
            key=lambda x: x["path"],
        ),
    }

    return manifest


def write_json(manifest: Dict[str, Any]) -> Path:
    json_path = ROOT / "endpoints_manifest.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    return json_path


def write_markdown(manifest: Dict[str, Any]) -> Path:
    md_path = ROOT / "ENDPOINTS_MANIFEST.md"

    lines: List[str] = []
    lines.append("# MORDZIX AI – Manifest endpointów\n")
    lines.append(f"- Root projektu: `{manifest['root']}`")
    lines.append(f"- Łącznie endpointów /api/*: **{manifest['total']}**\n")

    groups = manifest["groups"]
    for g_name in sorted(groups.keys()):
        g = groups[g_name]
        lines.append(f"## Grupa: `{g_name}`  ({g['count']} endpointów)\n")
        for r in sorted(g["routes"], key=lambda x: x["path"]):
            methods = ",".join(r["methods"]) or "-"
            module = r["module"] or ""
            endpoint = r["endpoint"] or ""
            handler = f"{module}.{endpoint}" if module or endpoint else ""
            tags = ", ".join(r["tags"]) if r["tags"] else ""
            meta_bits = []
            if handler:
                meta_bits.append(handler)
            if tags:
                meta_bits.append(f"tags: {tags}")
            meta = f"  _({'; '.join(meta_bits)})_" if meta_bits else ""
            lines.append(f"- `{methods:10s}` `{r['path']}`{meta}")
        lines.append("")  # pusta linia między grupami

    with md_path.open("w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    return md_path


# ======================================================================
#  Main
# ======================================================================

def main() -> None:
    print("======================================================================")
    print("[MANIFEST] Start generowania manifestu endpointów")
    print("======================================================================")

    manifest = collect_manifest(app)

    json_path = write_json(manifest)
    md_path = write_markdown(manifest)

    print("======================================================================")
    print("[MANIFEST] Gotowe.")
    print(f"[MANIFEST] JSON : {json_path}")
    print(f"[MANIFEST] MD   : {md_path}")
    print(f"[MANIFEST] Łącznie /api/*: {manifest['total']}")
    print("======================================================================")


if __name__ == "__main__":
    main()
