#!/usr/bin/env bash
set -e

cd /root/mordzix-ai

if ss -ltnp | grep -q ':8080'; then
  PID=$(ss -ltnp | awk '/:8080/ {sub(/.*pid=/,"",$NF); sub(/,.*/,"",$NF); print $NF}')
  echo "[CLEAN] Killing process on 8080 (PID=$PID)..."
  kill "$PID" || true
  sleep 2
fi

./start.sh
