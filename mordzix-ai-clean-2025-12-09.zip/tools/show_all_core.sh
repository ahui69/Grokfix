#!/usr/bin/env bash
set -euo pipefail

cd /root/mordzix-ai

FILES=(
  core/app.py
  core/assistant_endpoint.py
  core/config.py
  core/llm.py
  core/memory_db.py
  core/memory_router.py
  core/memory_wrapper.py
  core/_memory_fallback.py
)

echo "===== TREE core/ ====="
find core -maxdepth 2 -type f -name '*.py' | sort

echo
for f in "${FILES[@]}"; do
  echo
  echo "==================== BEGIN $f ===================="
  if [ -f "$f" ]; then
    sed -n '1,99999p' "$f"
  else
    echo "MISSING: $f"
  fi
  echo "==================== END $f ======================"
done

echo
echo "===== ROUTERS (core/**/router*.py) ====="
for r in $(find core -maxdepth 2 -type f -name '*router*.py' | sort); do
  echo
  echo "-------------------- $r --------------------"
  sed -n '1,99999p' "$r"
done

echo
echo "===== .env (zamaskowane sekrety) ====="
if [ -f .env ]; then
  awk -F= 'BEGIN{OFS="="}
    /TOKEN|KEY|SECRET|PASS|PWD|AUTH/ {print $1,"***MASKED***"; next}
    {print $0}' .env
else
  echo "MISSING: .env"
fi
