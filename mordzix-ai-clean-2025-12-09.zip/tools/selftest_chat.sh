#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-http://127.0.0.1:8080}"
AUTH="$(awk -F= '/^AUTH_TOKEN=/{print $2}' /root/mordzix-ai/.env | tr -d '\r')"

SID="$(curl -s -X POST "$BASE/api/sessions" \
  -H "Authorization: Bearer $AUTH" -H "Content-Type: application/json" \
  -d '{"title":"chat-selftest"}' | jq -r '.id')"

REQ=$(jq -n --arg sid "$SID" '{
  session_id:$sid, internet_allowed:false, use_research:false,
  temperature:0, max_tokens:32,
  messages:[{role:"user",content:"Wypisz dokładnie: PONG"}]
}')
curl -s -X POST "$BASE/api/chat/assistant" \
  -H "Authorization: Bearer '"$AUTH"'" -H "Content-Type: application/json" \
  -d "$REQ" | jq -r '.answer // .detail // .error'
