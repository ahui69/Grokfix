#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-http://127.0.0.1:8080}"
ENV="/root/mordzix-ai/.env"
AUTH="$(awk -F= '/^AUTH_TOKEN=/{print $2}' "$ENV" | tr -d '\r')"

# nowa sesja
SID="$(curl -sS -X POST "$BASE/api/sessions" \
  -H "Authorization: Bearer $AUTH" \
  -H "Content-Type: application/json" \
  -d '{"title":"mem-test"}' | jq -r '.id')"
echo "SID=$SID"

# zapis faktu
curl -sS -X POST "$BASE/api/memory/add" \
  -H "Authorization: Bearer $AUTH" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"$SID\",\"text\":\"Zamówienie #A123 klienta KUBA jest opłacone.\",\"tags\":[\"order\",\"A123\",\"KUBA\"]}" | jq .

# kontrola wyszukiwarki pamięci
curl -sS -X POST "$BASE/api/memory/search" \
  -H "Authorization: Bearer $AUTH" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"$SID\",\"q\":\"A123 KUBA\",\"limit\":5}" | jq .

# pytanie z use_memory=true (auto-injection)
REQ_AUTO=$(jq -n --arg sid "$SID" '{
  session_id:$sid, use_memory:true, internet_allowed:false, temperature:0, max_tokens:32,
  messages:[{role:"user",content:"Jaki jest status zamówienia #A123 klienta KUBA? Jedno zdanie."}]
}')
echo "[*] AUTO (use_memory=true):"
curl -sS -X POST "$BASE/api/chat/assistant" \
  -H "Authorization: Bearer $AUTH" \
  -H "Content-Type: application/json" \
  -d "$REQ_AUTO" | jq -r '.answer // .detail // .error'

# jeśli auto nie działa – przygotuj jawny injection
MEM="$(curl -sS -X POST "$BASE/api/memory/search" \
   -H "Authorization: Bearer $AUTH" \
   -H "Content-Type: application/json" \
   -d "{\"session_id\":\"$SID\",\"q\":\"A123 KUBA\",\"limit\":3}" | jq -r '.sources[]? // empty')"

REQ_FORCE="$(jq -n --arg sid "$SID" --arg mem "$MEM" '{
  session_id:$sid, use_memory:false, internet_allowed:false, temperature:0, max_tokens:32,
  messages:[
    {role:"system", content:( "UŻYJ WYŁĄCZNIE TEGO KONTEKSTU:\n\n" + $mem )},
    {role:"user",   content:"Jaki jest status zamówienia #A123 klienta KUBA? Jedno zdanie."}
  ]
}')"
echo "[*] FORCED (jawne wstrzyknięcie pamięci):"
curl -sS -X POST "$BASE/api/chat/assistant" \
  -H "Authorization: Bearer $AUTH" \
  -H "Content-Type: application/json" \
  -d "$REQ_FORCE" | jq -r '.answer // .detail // .error'
