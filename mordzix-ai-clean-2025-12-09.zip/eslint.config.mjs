import js from "@eslint/js";
import globals from "globals";

export default [
  js.configs.recommended,

  // Lintujemy TYLKO katalog(i) ze źródłami – PODMIEŃ 'frontend' jeśli masz inaczej
  {
    files: [
      "frontend/**/*.{js,jsx,ts,tsx}",
      "src/**/*.{js,jsx,ts,tsx}",
      "webui/**/*.{js,jsx,ts,tsx}"
    ],
    // Global ignore – żadnych paczek i buildów
    ignores: [
      "**/node_modules/**",
      "**/dist/**",
      "**/build/**",
      "**/.next/**",
      "**/out/**",
      "**/coverage/**",
      "**/public/**",
      "**/*.min.*",
      "**/*.bundle.*"
    ],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.serviceworker,
        ...globals.node
      }
    }
  },

  // (opcjonalnie) dodatkowe globy dla service workerów
  {
    files: [
      "frontend/**/*sw*.{js,ts,jsx,tsx}",
      "frontend/**/*worker*.{js,ts,jsx,tsx}",
      "public/**/sw.{js,ts}"
    ],
    languageOptions: { globals: { ...globals.serviceworker } }
  }
];
