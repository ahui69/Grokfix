import js from "@eslint/js";
import tseslint from "typescript-eslint";

/** @type {import("eslint").Linter.FlatConfig[]} */
export default [
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ["src/**/*.{js,jsx,ts,tsx}"],   // tylko źródła
    ignores: [
      "**/node_modules/**",
      "**/dist/**",
      "**/build/**",
      "**/.next/**",
      "**/out/**",
      "**/coverage/**",
      "**/*.min.js"
    ],
    rules: {
      "@typescript-eslint/no-unused-expressions": ["error", {
        allowShortCircuit: true,       // pozwól na: cond && fn()
        allowTernary: true,            // pozwól na: cond ? a : b
        allowTaggedTemplates: true     // pozwól na: tag`tpl`
      }]
    }
  },
  // testy (wyłącz tę regułę, jeśli używasz 'chai' itp.)
  {
    files: ["**/*.{test,spec}.{js,jsx,ts,tsx}"],
    rules: { "@typescript-eslint/no-unused-expressions": "off" }
  }
];
