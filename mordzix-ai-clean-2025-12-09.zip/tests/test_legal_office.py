#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testy dla modułu Legal Office - Pisma Urzędowe
"""

import pytest
import sys
import os
from datetime import datetime, timedelta

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.legal_office_endpoint import (
    LEGAL_KNOWLEDGE,
    ECONOMIC_KNOWLEDGE,
    identify_institution,
    identify_document_type,
    extract_key_info,
    calculate_deadline
)


class TestLegalKnowledge:
    """Testy bazy wiedzy prawnej"""
    
    def test_all_institutions_have_required_fields(self):
        """Każda instytucja musi mieć wymagane pola"""
        required_fields = ['name', 'laws', 'deadlines', 'common_issues']
        
        for inst_key, inst_data in LEGAL_KNOWLEDGE.items():
            for field in required_fields:
                assert field in inst_data, f"Brak pola '{field}' w instytucji '{inst_key}'"
    
    def test_institutions_count(self):
        """Sprawdza liczbę obsługiwanych instytucji"""
        assert len(LEGAL_KNOWLEDGE) >= 9, "Powinno być minimum 9 instytucji"
    
    def test_urzad_skarbowy_laws(self):
        """US musi mieć podstawowe ustawy"""
        us = LEGAL_KNOWLEDGE['urzad_skarbowy']
        laws_text = ' '.join(us['laws']).lower()
        
        assert 'ordynacja podatkowa' in laws_text
        assert 'pit' in laws_text or 'dochodow' in laws_text
        assert 'vat' in laws_text
    
    def test_zus_deadlines(self):
        """ZUS - sprawdzenie terminów"""
        zus = LEGAL_KNOWLEDGE['zus']
        
        assert zus['deadlines']['odwolanie'] == 30
        assert zus['deadlines']['sprzeciw_od_orzeczenia_lekarza'] == 14
    
    def test_komornik_laws(self):
        """Komornik - sprawdzenie ustaw"""
        komornik = LEGAL_KNOWLEDGE['komornik']
        laws_text = ' '.join(komornik['laws']).lower()
        
        assert 'kpc' in laws_text or 'cywilnego' in laws_text
        assert 'komornik' in laws_text


class TestEconomicKnowledge:
    """Testy wiedzy ekonomicznej"""
    
    def test_przedawnienie_values(self):
        """Sprawdza terminy przedawnienia"""
        przedawnienie = ECONOMIC_KNOWLEDGE['przedawnienie']
        
        assert przedawnienie['ogolne'] == 6
        assert przedawnienie['dzialalnosc_gospodarcza'] == 3
        assert przedawnienie['podatki'] == 5
        assert przedawnienie['skladki_zus'] == 5
    
    def test_odsetki_values(self):
        """Sprawdza stawki odsetek"""
        odsetki = ECONOMIC_KNOWLEDGE['odsetki']
        
        assert odsetki['ustawowe_za_opoznienie'] > 0
        assert odsetki['maksymalne'] == 20.0
    
    def test_kwoty_wolne(self):
        """Sprawdza kwoty wolne od zajęcia"""
        kwoty = ECONOMIC_KNOWLEDGE['kwoty_wolne']
        
        assert kwoty['minimalne_wynagrodzenie_2024'] > 4000
        assert kwoty['kwota_wolna_pit'] == 30000


class TestInstitutionIdentification:
    """Testy identyfikacji instytucji"""
    
    def test_identify_urzad_skarbowy(self):
        """Identyfikacja US"""
        texts = [
            "Naczelnik Urzędu Skarbowego w Warszawie",
            "DECYZJA w sprawie podatku dochodowego",
            "Pierwszy Urząd Skarbowy",
            "zaległości podatkowe PIT"
        ]
        
        for text in texts:
            result = identify_institution(text)
            assert result == 'urzad_skarbowy', f"Nie rozpoznano US w: '{text}'"
    
    def test_identify_zus(self):
        """Identyfikacja ZUS"""
        texts = [
            "Zakład Ubezpieczeń Społecznych",
            "DECYZJA ZUS Oddział w Krakowie",
            "składki na ubezpieczenie społeczne",
            "zasiłek chorobowy"
        ]
        
        for text in texts:
            result = identify_institution(text)
            assert result == 'zus', f"Nie rozpoznano ZUS w: '{text}'"
    
    def test_identify_komornik(self):
        """Identyfikacja Komornika"""
        texts = [
            "Komornik Sądowy przy Sądzie Rejonowym",
            "ZAWIADOMIENIE O WSZCZĘCIU EGZEKUCJI",
            "zajęcie wynagrodzenia za pracę"
        ]
        
        for text in texts:
            result = identify_institution(text)
            assert result == 'komornik', f"Nie rozpoznano Komornika w: '{text}'"
    
    def test_identify_sad(self):
        """Identyfikacja Sądu"""
        texts = [
            "Sąd Rejonowy w Poznaniu",
            "NAKAZ ZAPŁATY w postępowaniu upominawczym",
            "Sąd Okręgowy Wydział Cywilny"
        ]
        
        for text in texts:
            result = identify_institution(text)
            assert result == 'sad_cywilny', f"Nie rozpoznano Sądu w: '{text}'"


class TestDocumentTypeIdentification:
    """Testy identyfikacji typu dokumentu"""
    
    def test_identify_decyzja(self):
        """Identyfikacja decyzji"""
        texts = [
            "DECYZJA Nr 123/2024",
            "Na podstawie art. 207 KPA postanawiam",
            "wydaję następującą DECYZJĘ"
        ]
        
        for text in texts:
            result = identify_document_type(text)
            assert result == 'decyzja', f"Nie rozpoznano decyzji w: '{text}'"
    
    def test_identify_nakaz_zaplaty(self):
        """Identyfikacja nakazu zapłaty"""
        texts = [
            "NAKAZ ZAPŁATY",
            "nakaz zapłaty w postępowaniu upominawczym",
            "Sąd wydaje nakaz zapłaty"
        ]
        
        for text in texts:
            result = identify_document_type(text)
            assert result == 'nakaz_zaplaty', f"Nie rozpoznano nakazu w: '{text}'"
    
    def test_identify_wezwanie(self):
        """Identyfikacja wezwania"""
        texts = [
            "WEZWANIE DO ZAPŁATY",
            "Wzywam do uregulowania należności",
            "wezwanie do złożenia wyjaśnień"
        ]
        
        for text in texts:
            result = identify_document_type(text)
            assert result == 'wezwanie', f"Nie rozpoznano wezwania w: '{text}'"


class TestKeyInfoExtraction:
    """Testy ekstrakcji kluczowych informacji"""
    
    def test_extract_sygnatura(self):
        """Ekstrakcja sygnatury"""
        text = "Sygn. akt I C 123/24, sprawa o zapłatę"
        result = extract_key_info(text)
        
        assert 'sygnatura' in result
        assert '123' in result['sygnatura']
    
    def test_extract_kwota(self):
        """Ekstrakcja kwoty"""
        texts = [
            ("kwota 5000,00 zł", "5000"),
            ("należność: 12 345,67 PLN", "12345"),
            ("zobowiązanie 100.50 zł", "100")
        ]
        
        for text, expected in texts:
            result = extract_key_info(text)
            assert 'kwota' in result, f"Brak kwoty w: '{text}'"
    
    def test_extract_termin(self):
        """Ekstrakcja terminu"""
        text = "termin 14 dni od dnia doręczenia"
        result = extract_key_info(text)
        
        assert 'termin' in result
        assert '14' in result['termin']


class TestDeadlineCalculation:
    """Testy kalkulatora terminów"""
    
    def test_calculate_deadline_us_odwolanie(self):
        """Obliczenie terminu odwołania do US"""
        from datetime import date
        
        doc_date = date(2024, 12, 1)
        result = calculate_deadline(doc_date, 'urzad_skarbowy', 'odwolanie')
        
        expected = date(2024, 12, 15)  # 14 dni
        assert result == expected
    
    def test_calculate_deadline_zus_odwolanie(self):
        """Obliczenie terminu odwołania do ZUS"""
        from datetime import date
        
        doc_date = date(2024, 12, 1)
        result = calculate_deadline(doc_date, 'zus', 'odwolanie')
        
        expected = date(2024, 12, 31)  # 30 dni
        assert result == expected


class TestIntegration:
    """Testy integracyjne"""
    
    def test_full_document_analysis(self):
        """Pełna analiza dokumentu"""
        document = """
        Naczelnik Pierwszego Urzędu Skarbowego w Warszawie
        
        DECYZJA Nr PIT-123/2024
        
        Na podstawie art. 207 Ordynacji podatkowej
        
        Określam zobowiązanie podatkowe w kwocie 15.000,00 zł
        
        Termin do wniesienia odwołania: 14 dni
        
        Sygn. akt: 1US/PIT/2024/12345
        """
        
        institution = identify_institution(document)
        doc_type = identify_document_type(document)
        key_info = extract_key_info(document)
        
        assert institution == 'urzad_skarbowy'
        assert doc_type == 'decyzja'
        assert 'kwota' in key_info or 'sygnatura' in key_info


# Uruchom testy
if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
