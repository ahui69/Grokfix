#!/bin/bash
# 🚀 URUCHOM TO NA OVH VPS!

echo "╔══════════════════════════════════════════════════════════╗"
echo "║  🔥 MORDZIX AI - QUICK START                            ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Sprawdź czy jesteś w folderze full/
if [ ! -f "start.sh" ]; then
    echo "❌ Błąd: Nie jesteś w folderze full/"
    echo "   Uruchom: cd ~/full && ./START_OVH.sh"
    exit 1
fi

echo "✅ Folder full/ znaleziony"
echo ""

# Sprawdź .env
if [ ! -f ".env" ]; then
    echo "⚠️  Brak .env - kopiuję z .env.example..."
    cp .env.example .env
    echo ""
    echo "⚠️  WYPEŁNIJ KLUCZE API W .env!"
    echo "   nano .env"
    echo ""
    exit 1
fi

echo "✅ .env znaleziony"
echo ""

# Sprawdź Python
if ! command -v python3 &> /dev/null; then
    echo "⚠️  Instaluję Python3..."
    sudo apt update && sudo apt install -y python3 python3-pip
fi

echo "✅ Python OK"
echo ""

# Uruchom start.sh
echo "🚀 Uruchamiam aplikację..."
echo ""
chmod +x start.sh
./start.sh
